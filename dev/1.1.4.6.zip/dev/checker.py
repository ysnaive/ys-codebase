"""
Compliance & Architecture Checker for YS-Codebase modules.
Implements 8-step compliance check pipeline, 3-tier severity classification,
and AST static security/anti-pattern analysis.
"""
import os
import sys
import ast
import json
import importlib
from enum import Enum
from dataclasses import dataclass, field
from typing import Tuple, List, Dict, Optional, Any, Set
from core import uri, vfs, semver, contributes
from core.symbols import parse_code_func_uri, resolve_callable


class CheckSeverity(Enum):
    PASS = "PASS"
    WARN = "WARN"
    FAIL = "FAIL"


@dataclass
class CheckIssue:
    severity: CheckSeverity
    category: str        # "MANIFEST", "CONTRIBUTES", "PROBING", "STRUCTURE", "ANTIPATTERN", "SYNTAX"
    message: str
    file_path: Optional[str] = None
    line_number: Optional[int] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "severity": self.severity.value,
            "category": self.category,
            "message": self.message,
            "file_path": self.file_path,
            "line_number": self.line_number,
        }


@dataclass
class CheckReport:
    module: str
    issues: List[CheckIssue] = field(default_factory=list)

    @property
    def has_fails(self) -> bool:
        return any(i.severity == CheckSeverity.FAIL for i in self.issues)

    @property
    def has_warns(self) -> bool:
        return any(i.severity == CheckSeverity.WARN for i in self.issues)

    @property
    def status(self) -> CheckSeverity:
        if self.has_fails:
            return CheckSeverity.FAIL
        elif self.has_warns:
            return CheckSeverity.WARN
        return CheckSeverity.PASS

    @property
    def passed(self) -> bool:
        return not self.has_fails

    @property
    def errors(self) -> List[str]:
        return [i.message for i in self.issues if i.severity == CheckSeverity.FAIL]

    @property
    def warnings(self) -> List[str]:
        return [i.message for i in self.issues if i.severity == CheckSeverity.WARN]

    @property
    def agent_directive(self) -> Optional[str]:
        if not self.has_fails:
            return None
        return (
            "[Agent Directive] Please consult skill 'yscb-module-dev' "
            "(references/acceptance_checklist.md & references/contributes_guide.md) "
            "to resolve module compliance errors."
        )

    def format_report(self) -> str:
        lines = [f"[*] Module: {self.module:<50} [{self.status.value}]"]
        for issue in self.issues:
            loc = f" ({issue.file_path})" if issue.file_path else ""
            lines.append(f"    |-- [{issue.severity.value}] [{issue.category}]{loc} {issue.message}")
        if self.agent_directive and not any(i.category == "DIRECTIVE" for i in self.issues):
            lines.append(self.agent_directive)
        return "\n".join(lines)

    def to_dict(self) -> Dict[str, Any]:
        res: Dict[str, Any] = {
            "module": self.module,
            "status": self.status.value,
            "passed": self.passed,
            "issues": [i.to_dict() for i in self.issues],
        }
        if self.agent_directive:
            res["agent_directive"] = self.agent_directive
        return res


def _extract_ast_tokens(expr_node: ast.AST) -> List[str]:
    tokens: List[str] = []
    for n in ast.walk(expr_node):
        if isinstance(n, ast.Attribute):
            tokens.append(n.attr)
        elif isinstance(n, ast.Name):
            tokens.append(n.id)
    return tokens


def _collect_declared_cli_commands(module_dir: str) -> List[Tuple[str, str]]:
    """Collect (full_cmd, primary_cmd) pairs from contributes/core.json if present."""
    contrib_file = os.path.join(module_dir, "contributes", "core.json")
    if not os.path.isfile(contrib_file):
        return []
    try:
        with open(contrib_file, "r", encoding="utf-8") as f:
            cdata = json.load(f)
        cmd_map = cdata.get("commands", {}).get("cmd", {})
        if not isinstance(cmd_map, dict) or not cmd_map:
            return []

        def _collect_leaves(d: dict, pfx: str = "") -> List[Tuple[str, str]]:
            leaves: List[Tuple[str, str]] = []
            for k, v in d.items():
                if isinstance(v, dict) and isinstance(v.get("cmd"), dict) and v["cmd"]:
                    leaves.extend(_collect_leaves(v["cmd"], pfx=f"{pfx}{k}_"))
                else:
                    full_c = f"{pfx}{k}"
                    primary_c = full_c.split("_", 1)[0]
                    leaves.append((full_c, primary_c))
            return leaves

        return _collect_leaves(cmd_map)
    except (OSError, json.JSONDecodeError):
        return []


def _audit_cli_script_ast(
    tree: ast.Module,
) -> Tuple[Set[str], bool, bool, List[Tuple[int, str]]]:
    """Scan scripts/cli.py top-level AST nodes for functions, forbidden main, and top-level statements."""
    declared_funcs: Set[str] = set()
    has_main_func = False
    has_if_name_main = False
    invalid_top_level_nodes: List[Tuple[int, str]] = []

    for node in tree.body:
        if isinstance(node, (ast.Import, ast.ImportFrom, ast.ClassDef)):
            continue
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            declared_funcs.add(node.name)
            if node.name == "main":
                has_main_func = True
            continue
        if isinstance(node, ast.Expr):
            if isinstance(node.value, ast.Constant) and isinstance(node.value.value, str):
                continue
            invalid_top_level_nodes.append((getattr(node, "lineno", 0), "top-level expression"))
        elif isinstance(node, ast.If):
            is_name_main = False
            if isinstance(node.test, ast.Compare):
                left = node.test.left
                if isinstance(left, ast.Name) and left.id == "__name__":
                    for comp in node.test.comparators:
                        if isinstance(comp, ast.Constant) and comp.value == "__main__":
                            is_name_main = True
                            break
            if is_name_main:
                has_if_name_main = True
            else:
                invalid_top_level_nodes.append((getattr(node, "lineno", 0), "top-level if-statement"))
        else:
            stmt_type = type(node).__name__
            invalid_top_level_nodes.append((getattr(node, "lineno", 0), f"top-level statement '{stmt_type}'"))

    return declared_funcs, has_main_func, has_if_name_main, invalid_top_level_nodes


def _check_require_decorator_node(target_node: ast.AST, t_file: str, report: CheckReport) -> None:
    """Inspect @require(...) decorator on a test class or test function for LOGIC + ISOLATED_SANDBOX conflict."""
    for dec in getattr(target_node, "decorator_list", []):
        if not isinstance(dec, ast.Call) or not dec.args:
            continue
        func_name = getattr(dec.func, "id", getattr(dec.func, "attr", ""))
        if func_name != "require":
            continue
        tokens = _extract_ast_tokens(dec.args[0])
        if "LOGIC" in tokens and "ISOLATED_SANDBOX" in tokens:
            node_kind = "class" if isinstance(target_node, ast.ClassDef) else "function"
            lineno = getattr(target_node, "lineno", 0)
            report.issues.append(
                CheckIssue(
                    severity=CheckSeverity.WARN,
                    category="ANTIPATTERN",
                    message=(
                        f"Anti-Pattern: Test {node_kind} '{getattr(target_node, 'name', '')}' in tests/{t_file}:{lineno} "
                        f"is marked with both 'LOGIC' and 'ISOLATED_SANDBOX'. Pure logical tests should not request dedicated per-method sandbox isolation."
                    ),
                    file_path=f"tests/{t_file}",
                    line_number=lineno,
                )
            )


def _method_has_none_requirement(item: ast.AST) -> bool:
    for dec in getattr(item, "decorator_list", []):
        if isinstance(dec, ast.Call) and dec.args:
            f_name = getattr(dec.func, "id", getattr(dec.func, "attr", ""))
            if f_name == "require" and "NONE" in _extract_ast_tokens(dec.args[0]):
                return True
    return False


def _method_calls_mark_passed(item: ast.AST) -> bool:
    for sub_n in ast.walk(item):
        if isinstance(sub_n, ast.Call) and isinstance(sub_n.func, ast.Attribute):
            if sub_n.func.attr == "mark_passed" and isinstance(sub_n.func.value, ast.Name) and sub_n.func.value.id == "self":
                return True
    return False


def _verify_test_class_isolation_and_marks(
    class_node: ast.ClassDef,
    t_file: str,
    report: CheckReport,
    is_top_level: bool = False,
) -> None:
    """Validate that a Test* class (or top-level TestCase class) inherits from YSCBTestCase and calls self.mark_passed() in test_* methods."""
    base_names = [
        b.id if isinstance(b, ast.Name) else b.attr
        for b in class_node.bases
        if isinstance(b, (ast.Name, ast.Attribute))
    ]
    if not (class_node.name.startswith("Test") or (is_top_level and any(b in ("TestCase", "YSCBTestCase") for b in base_names))):
        return

    if "TestCase" in base_names and "YSCBTestCase" not in base_names:
        report.issues.append(
            CheckIssue(
                severity=CheckSeverity.FAIL,
                category="STRUCTURE",
                message=(
                    f"Security Guard: Test class '{class_node.name}' in tests/{t_file}:{class_node.lineno} "
                    f"directly subclasses 'unittest.TestCase'. Must inherit from 'dev.testing.case.YSCBTestCase'."
                ),
                file_path=f"tests/{t_file}",
                line_number=class_node.lineno,
            )
        )
        return

    for item in class_node.body:
        if not isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)) or not item.name.startswith("test_"):
            continue
        if _method_has_none_requirement(item):
            continue
        if not _method_calls_mark_passed(item):
            report.issues.append(
                CheckIssue(
                    severity=CheckSeverity.WARN,
                    category="STRUCTURE",
                    message=(
                        f"Test method '{item.name}' in tests/{t_file}:{item.lineno} lacks 'self.mark_passed()' call. "
                        f"Unhandled tests will be marked as UNKNOWN in test runner."
                    ),
                    file_path=f"tests/{t_file}",
                    line_number=item.lineno,
                )
            )


def _is_core_spec_at_least_1_2_0(core_spec: Any) -> bool:
    """Verify via multi-point probing and literal inspection that core_spec requires core >= 1.2.0."""
    if not isinstance(core_spec, str) or not core_spec.strip():
        return False
    min_required = semver.parse_semver("1.2.0.0")
    low_probes = ["0.1.0.0", "1.0.0.0", "1.1.0.0", "1.1.99.99"]
    high_probes = ["1.2.0.0", "1.2.7.0", "1.3.0.0", "2.0.0.0"]
    for token in core_spec.replace(",", " ").replace(";", " ").split():
        ver_str = token.lstrip("><=!~^vV").strip()
        if not ver_str:
            continue
        try:
            vt = semver.parse_semver(ver_str)
            if semver.compare_semver(vt, min_required) < 0:
                low_probes.append(ver_str)
            else:
                high_probes.append(ver_str)
        except Exception:
            pass
    try:
        if any(semver.match_constraint(p, core_spec) for p in low_probes):
            return False
        return any(semver.match_constraint(p, core_spec) for p in high_probes)
    except Exception:
        return False


class Checker:
    def __init__(self) -> None:
        self._parsed_py_cache: Dict[str, Any] = {}
        self._syntax_reported_files: Set[str] = set()

    def _get_parsed_py(self, full_path: str, filename: Optional[str] = None) -> Tuple[str, ast.Module]:
        """Reads and parses a Python file into (content, ast.Module), caching per check_module run."""
        norm_p = os.path.abspath(full_path)
        if norm_p in self._parsed_py_cache:
            cached = self._parsed_py_cache[norm_p]
            if isinstance(cached, BaseException):
                raise cached
            return cached
        try:
            with open(full_path, "r", encoding="utf-8", errors="replace") as f:
                content = f.read()
            tree = ast.parse(content, filename=filename or full_path)
            self._parsed_py_cache[norm_p] = (content, tree)
            return content, tree
        except Exception as exc:
            self._parsed_py_cache[norm_p] = exc
            raise

    def _record_syntax_issue(self, report: CheckReport, norm_p: str, rel_p: str, exc: Exception) -> None:
        if norm_p in self._syntax_reported_files:
            return
        self._syntax_reported_files.add(norm_p)
        if isinstance(exc, SyntaxError):
            msg = f"SyntaxError in {rel_p}:{exc.lineno}: {exc.msg}"
            lineno = exc.lineno
        else:
            msg = f"Error parsing {rel_p}: {exc}"
            lineno = None
        report.issues.append(
            CheckIssue(
                severity=CheckSeverity.FAIL,
                category="SYNTAX",
                message=msg,
                file_path=rel_p,
                line_number=lineno,
            )
        )

    def check_module(self, name: str) -> CheckReport:
        self._parsed_py_cache = {}
        self._syntax_reported_files = set()
        report = CheckReport(module=name)
        src_uri = f"module.source://{name}"
        if not vfs.exists(src_uri):
            report.issues.append(
                CheckIssue(
                    severity=CheckSeverity.FAIL,
                    category="MANIFEST",
                    message=f"Module source not found at {src_uri}.",
                )
            )
        else:
            real_dir = uri.resolve(src_uri)
            m_data = self._check_manifest(name, real_dir, report)
            self._check_core_injection(name, real_dir, report, m_data=m_data)
            self._check_file_structure(name, real_dir, report)
            self._check_source_files(name, real_dir, report)
            self._check_test_classes(name, real_dir, report)
            self._check_sandbox_hooks(name, real_dir, report)
            self._check_docs_pollution(name, real_dir, report)
            self._check_custom_rules(name, real_dir, report)

        if report.has_fails and report.agent_directive:
            report.issues.append(
                CheckIssue(
                    severity=CheckSeverity.FAIL,
                    category="DIRECTIVE",
                    message=report.agent_directive,
                )
            )
        return report

    def _check_manifest(self, name: str, real_dir: str, report: CheckReport) -> Optional[Dict[str, Any]]:
        manifest_path = os.path.join(real_dir, "manifest.json")
        if not os.path.exists(manifest_path):
            report.issues.append(
                CheckIssue(
                    severity=CheckSeverity.FAIL,
                    category="MANIFEST",
                    message="Missing 'manifest.json'.",
                    file_path="manifest.json",
                )
            )
            return None

        try:
            with open(manifest_path, "r", encoding="utf-8") as f:
                m_data = json.load(f)
            if not isinstance(m_data, dict):
                report.issues.append(
                    CheckIssue(
                        severity=CheckSeverity.FAIL,
                        category="MANIFEST",
                        message="Invalid JSON in manifest.json: root must be an object.",
                        file_path="manifest.json",
                    )
                )
                return None

            for field_name in ("name", "version", "entry", "dependencies"):
                if field_name not in m_data:
                    report.issues.append(
                        CheckIssue(
                            severity=CheckSeverity.FAIL,
                            category="MANIFEST",
                            message=f"Missing required field '{field_name}' in manifest.json.",
                            file_path="manifest.json",
                        )
                    )

            m_name = m_data.get("name")
            if m_name and m_name != name:
                report.issues.append(
                    CheckIssue(
                        severity=CheckSeverity.FAIL,
                        category="MANIFEST",
                        message=f"Manifest name '{m_name}' does not match directory name '{name}'.",
                        file_path="manifest.json",
                    )
                )

            m_ver = m_data.get("version")
            if m_ver:
                try:
                    semver.parse_semver(str(m_ver))
                except ValueError:
                    report.issues.append(
                        CheckIssue(
                            severity=CheckSeverity.FAIL,
                            category="MANIFEST",
                            message=f"Manifest version '{m_ver}' is not a valid SemVer format.",
                            file_path="manifest.json",
                        )
                    )

            deps = m_data.get("dependencies")
            if deps is not None:
                if not isinstance(deps, (list, dict)):
                    report.issues.append(
                        CheckIssue(
                            severity=CheckSeverity.FAIL,
                            category="MANIFEST",
                            message="'dependencies' field must be a list or object.",
                            file_path="manifest.json",
                        )
                    )
                elif name != "core":
                    dep_names = deps if isinstance(deps, list) else list(deps.keys())
                    if "core" not in dep_names:
                        report.issues.append(
                            CheckIssue(
                                severity=CheckSeverity.FAIL,
                                category="MANIFEST",
                                message="Module must explicitly declare 'core' in 'dependencies'.",
                                file_path="manifest.json",
                            )
                        )

            opt = m_data.get("optional")
            if opt is not None:
                if not isinstance(opt, dict):
                    report.issues.append(
                        CheckIssue(
                            severity=CheckSeverity.FAIL,
                            category="MANIFEST",
                            message="'optional' field must be an object/dict mapping module names to config.",
                            file_path="manifest.json",
                        )
                    )
                else:
                    for opt_mod, opt_cfg in opt.items():
                        if not isinstance(opt_cfg, dict):
                            report.issues.append(
                                CheckIssue(
                                    severity=CheckSeverity.FAIL,
                                    category="MANIFEST",
                                    message=f"Optional module '{opt_mod}' configuration must be an object with 'version' and 'hint'.",
                                    file_path="manifest.json",
                                )
                            )
                        else:
                            if "version" not in opt_cfg or not isinstance(opt_cfg["version"], str) or not opt_cfg["version"].strip():
                                report.issues.append(
                                    CheckIssue(
                                        severity=CheckSeverity.FAIL,
                                        category="MANIFEST",
                                        message=f"Optional module '{opt_mod}' missing non-empty string 'version'.",
                                        file_path="manifest.json",
                                    )
                                )
                            if "hint" not in opt_cfg or not isinstance(opt_cfg["hint"], str) or not opt_cfg["hint"].strip():
                                report.issues.append(
                                    CheckIssue(
                                        severity=CheckSeverity.FAIL,
                                        category="MANIFEST",
                                        message=f"Optional module '{opt_mod}' missing non-empty string 'hint'.",
                                        file_path="manifest.json",
                                    )
                                )

            onboarding = m_data.get("onboarding")
            if onboarding is not None:
                if not isinstance(onboarding, list) or any(not isinstance(item, str) or not item.strip() for item in onboarding):
                    report.issues.append(
                        CheckIssue(
                            severity=CheckSeverity.FAIL,
                            category="MANIFEST",
                            message="'onboarding' field in manifest.json must be a list of non-empty strings.",
                            file_path="manifest.json",
                        )
                    )

            rel_meta = m_data.get("release")
            if rel_meta is not None:
                if not isinstance(rel_meta, dict):
                    report.issues.append(
                        CheckIssue(
                            severity=CheckSeverity.FAIL,
                            category="MANIFEST",
                            message="'release' field in manifest.json must be a JSON object.",
                            file_path="manifest.json",
                        )
                    )
                else:
                    for rk in ("type", "urgency", "summary"):
                        if rk in rel_meta and (not isinstance(rel_meta[rk], str) or not rel_meta[rk].strip()):
                            report.issues.append(
                                CheckIssue(
                                    severity=CheckSeverity.FAIL,
                                    category="MANIFEST",
                                    message=f"'release.{rk}' in manifest.json must be a non-empty string.",
                                    file_path="manifest.json",
                                )
                            )

            self._check_pip_dependencies(name, m_data, report)
            if isinstance(m_ver, str) and m_ver.strip():
                self._check_package_dunder_version(name, real_dir, m_ver.strip(), report)
            return m_data
        except Exception as e:
            report.issues.append(
                CheckIssue(
                    severity=CheckSeverity.FAIL,
                    category="MANIFEST",
                    message=f"Invalid JSON in manifest.json: {e}",
                    file_path="manifest.json",
                )
            )
            return None

    def _check_package_dunder_version(self, name: str, real_dir: str, manifest_ver: str, report: CheckReport) -> None:
        """Verify that top-level package `__init__.py` `__version__` string literal (if present) matches `manifest.json` version."""
        try:
            entries = os.listdir(real_dir)
        except OSError:
            return
        for entry in sorted(entries):
            if entry in ("tests", "scripts", "contributes", "configurable", "assets", "skills") or entry.startswith("."):
                continue
            init_path = os.path.join(real_dir, entry, "__init__.py")
            if not os.path.isfile(init_path):
                continue
            rel_init = f"{entry}/__init__.py"
            try:
                _, tree = self._get_parsed_py(init_path, filename=rel_init)
            except Exception:
                continue
            for node in tree.body:
                target_names: List[str] = []
                val_node: Optional[ast.AST] = None
                if isinstance(node, ast.Assign):
                    target_names = [t.id for t in node.targets if isinstance(t, ast.Name)]
                    val_node = node.value
                elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
                    target_names = [node.target.id]
                    val_node = node.value
                if "__version__" in target_names and isinstance(val_node, ast.Constant) and isinstance(val_node.value, str):
                    dunder_ver = val_node.value.strip()
                    if dunder_ver != manifest_ver:
                        report.issues.append(
                            CheckIssue(
                                severity=CheckSeverity.FAIL,
                                category="MANIFEST",
                                message=(
                                    f"Package __version__ mismatch in '{rel_init}': "
                                    f"__version__ is '{dunder_ver}', but manifest.json version is '{manifest_ver}'."
                                ),
                                file_path=rel_init,
                                line_number=getattr(node, "lineno", None),
                            )
                        )

    def _check_pip_dependencies(self, name: str, m_data: Dict[str, Any], report: CheckReport) -> None:
        if "pip_dependencies" not in m_data:
            return

        pip_deps = m_data.get("pip_dependencies")
        if not isinstance(pip_deps, dict):
            report.issues.append(
                CheckIssue(
                    severity=CheckSeverity.FAIL,
                    category="MANIFEST",
                    message="'pip_dependencies' field must be an object (dict).",
                    file_path="manifest.json",
                )
            )
            return

        for pkg_name, spec in pip_deps.items():
            if not isinstance(pkg_name, str) or not pkg_name.strip():
                report.issues.append(
                    CheckIssue(
                        severity=CheckSeverity.FAIL,
                        category="MANIFEST",
                        message=f"Invalid package name in 'pip_dependencies': '{pkg_name}'. Must be a non-empty string.",
                        file_path="manifest.json",
                    )
                )
            elif spec is not None and not isinstance(spec, str):
                report.issues.append(
                    CheckIssue(
                        severity=CheckSeverity.FAIL,
                        category="MANIFEST",
                        message=f"Invalid version specification for package '{pkg_name}' in 'pip_dependencies': expected string or null, got {type(spec).__name__}.",
                        file_path="manifest.json",
                    )
                )

    def _check_core_injection(
        self,
        name: str,
        real_dir: str,
        report: CheckReport,
        m_data: Optional[Dict[str, Any]] = None,
    ) -> None:
        core_contribute_path = os.path.join(real_dir, "contributes", "core.json")
        if name != "core" and not os.path.exists(core_contribute_path):
            report.issues.append(
                CheckIssue(
                    severity=CheckSeverity.WARN,
                    category="CONTRIBUTES",
                    message="Module lacks 'contributes/core.json' declaration. Consider declaring CLI commands or URI schemes.",
                    file_path="contributes/core.json",
                )
            )

        contrib_dir = os.path.join(real_dir, "contributes")
        if not os.path.isdir(contrib_dir):
            return

        from core.validator import ContributesValidator

        # 1. Meta-Check: _format.json if present
        fmt_path = os.path.join(contrib_dir, "_format.json")
        if os.path.exists(fmt_path):
            try:
                with open(fmt_path, "r", encoding="utf-8") as f:
                    fmt_data = json.load(f)
                meta_res = ContributesValidator.validate_format_schema(fmt_data)
                for err in meta_res.errors:
                    report.issues.append(
                        CheckIssue(
                            severity=CheckSeverity.FAIL,
                            category="CONTRIBUTES",
                            message=f"Invalid _format.json schema: [{err.path}] {err.message}",
                            file_path="contributes/_format.json",
                        )
                    )
                for w in meta_res.warnings:
                    report.issues.append(
                        CheckIssue(
                            severity=CheckSeverity.WARN,
                            category="CONTRIBUTES",
                            message=f"_format.json note: [{w.path}] {w.message}",
                            file_path="contributes/_format.json",
                        )
                    )
            except Exception as e:
                report.issues.append(
                    CheckIssue(
                        severity=CheckSeverity.FAIL,
                        category="CONTRIBUTES",
                        message=f"Syntax error in 'contributes/_format.json': {e}",
                        file_path="contributes/_format.json",
                    )
                )

        # 2. Ingress & Egress Boundary Check on <target>.json
        try:
            files = sorted(f for f in os.listdir(contrib_dir) if f.endswith(".json"))
        except OSError:
            files = []

        for fname in files:
            if fname.startswith("_"):
                continue
            target = fname[:-5]
            f_path = os.path.join(contrib_dir, fname)
            try:
                with open(f_path, "r", encoding="utf-8") as f:
                    c_data = json.load(f)
            except Exception as e:
                report.issues.append(
                    CheckIssue(
                        severity=CheckSeverity.FAIL,
                        category="CONTRIBUTES",
                        message=f"Syntax error in 'contributes/{fname}': {e}",
                        file_path=f"contributes/{fname}",
                    )
                )
                continue

            target_fmt = None
            src_fmt_uri = f"module.source://{target}/contributes/_format.json"
            if vfs.exists(src_fmt_uri):
                try:
                    target_fmt = vfs.read_json(src_fmt_uri)
                except Exception:
                    target_fmt = None
            if target_fmt is None:
                target_fmt = contributes.get_format(target)
            if target_fmt is None:
                continue

            val_res = ContributesValidator.validate(target, c_data, donor_mod=name, format_schema=target_fmt, strict_points=True)
            if target == "core" and isinstance(c_data, dict) and "locales" in c_data and isinstance(c_data["locales"], dict):
                if name != "core":
                    manifest_obj = m_data
                    if manifest_obj is None:
                        manifest_path = os.path.join(real_dir, "manifest.json")
                        if os.path.exists(manifest_path):
                            try:
                                with open(manifest_path, "r", encoding="utf-8") as mf:
                                    loaded_mf = json.load(mf)
                                if isinstance(loaded_mf, dict):
                                    manifest_obj = loaded_mf
                            except (OSError, json.JSONDecodeError):
                                manifest_obj = None
                    if isinstance(manifest_obj, dict):
                        deps = manifest_obj.get("dependencies")
                        core_spec = deps.get("core") if isinstance(deps, dict) else None
                        if not _is_core_spec_at_least_1_2_0(core_spec):
                            report.issues.append(
                                CheckIssue(
                                    severity=CheckSeverity.FAIL,
                                    category="MANIFEST",
                                    message=(
                                        f"Module '{name}' declares 'locales' in 'contributes/core.json' "
                                        f"which requires 'core' >= 1.2.0 in 'manifest.json' dependencies "
                                        f"(found: {core_spec!r})."
                                    ),
                                    file_path="manifest.json",
                                )
                            )
                try:
                    from core import locale as core_locale
                    loc_res = core_locale.validate_module_locales(name, c_data["locales"], base_dir=real_dir)
                    val_res.issues.extend(loc_res.issues)
                    val_res.is_valid = len([i for i in val_res.issues if i.severity == "ERROR"]) == 0
                except Exception as e:
                    report.issues.append(
                        CheckIssue(
                            severity=CheckSeverity.FAIL,
                            category="CONTRIBUTES",
                            message=f"Locale validation error in 'contributes/{fname}': {e}",
                            file_path=f"contributes/{fname}",
                        )
                    )
            for err in val_res.errors:
                hint = f" ({err.suggestion})" if err.suggestion else ""
                report.issues.append(
                    CheckIssue(
                        severity=CheckSeverity.FAIL,
                        category="CONTRIBUTES",
                        message=f"Schema violation in 'contributes/{fname}': [{err.path}] {err.message}{hint}",
                        file_path=f"contributes/{fname}",
                    )
                )
            for w in val_res.warnings:
                hint = f" ({w.suggestion})" if w.suggestion else ""
                report.issues.append(
                    CheckIssue(
                        severity=CheckSeverity.WARN,
                        category="CONTRIBUTES",
                        message=f"Schema warning in 'contributes/{fname}': [{w.path}] {w.message}{hint}",
                        file_path=f"contributes/{fname}",
                    )
                )

    def _check_file_structure(self, name: str, real_dir: str, report: CheckReport) -> None:
        # 1. Entry point check
        cli_path = os.path.join(real_dir, "scripts", "cli.py")
        if not os.path.exists(cli_path):
            report.issues.append(
                CheckIssue(
                    severity=CheckSeverity.FAIL,
                    category="STRUCTURE",
                    message="Missing entry point 'scripts/cli.py'.",
                    file_path="scripts/cli.py",
                )
            )
        else:
            self._check_cli_compliance(name, cli_path, report)

        # 2. Check for scattered config.*.json at root
        for item in sorted(os.listdir(real_dir)):
            if item.startswith("config.") and item.endswith(".json"):
                report.issues.append(
                    CheckIssue(
                        severity=CheckSeverity.FAIL,
                        category="STRUCTURE",
                        message=f"Scattered config template found at module root: '{item}'. Templates must be placed under 'configurable/' directory.",
                        file_path=item,
                    )
                )

        # 3. Check configurable/ templates validity if present
        cfg_dir = os.path.join(real_dir, "configurable")
        if os.path.isdir(cfg_dir):
            for cfg_f in sorted(os.listdir(cfg_dir)):
                if not ((cfg_f.startswith("config.") and cfg_f.endswith(".json")) or cfg_f == "_format.json"):
                    report.issues.append(
                        CheckIssue(
                            severity=CheckSeverity.WARN,
                            category="STRUCTURE",
                            message=f"Non-standard configuration template naming in 'configurable/{cfg_f}'. Expected pattern 'config.*.json' or '_format.json'.",
                            file_path=f"configurable/{cfg_f}",
                        )
                    )
                if cfg_f.endswith(".json"):
                    cfg_full = os.path.join(cfg_dir, cfg_f)
                    try:
                        with open(cfg_full, "r", encoding="utf-8") as f:
                            json.load(f)
                    except Exception as e:
                        report.issues.append(
                            CheckIssue(
                                severity=CheckSeverity.FAIL,
                                category="STRUCTURE",
                                message=f"Invalid JSON in 'configurable/{cfg_f}': {e}",
                                file_path=f"configurable/{cfg_f}",
                            )
                        )

        # 4. Check for leftover temp files
        for root, dirs, files in os.walk(real_dir):
            dirs[:] = sorted(d for d in dirs if d not in ("__pycache__", ".pytest_cache", ".git"))
            for f in sorted(files):
                if f.endswith((".tmp", ".bak", ".DS_Store")) or f.endswith("~"):
                    rel_p = os.path.relpath(os.path.join(root, f), real_dir).replace("\\", "/")
                    report.issues.append(
                        CheckIssue(
                            severity=CheckSeverity.WARN,
                            category="STRUCTURE",
                            message=f"Found leftover temporary/junk file: '{rel_p}'.",
                            file_path=rel_p,
                        )
                    )

        # 5. Check contributes/_manifest.md presence
        contrib_dir = os.path.join(real_dir, "contributes")
        if os.path.isdir(contrib_dir):
            manifest_doc = os.path.join(contrib_dir, "_manifest.md")
            if not os.path.exists(manifest_doc):
                report.issues.append(
                    CheckIssue(
                        severity=CheckSeverity.FAIL,
                        category="CONTRIBUTES",
                        message="Module defines 'contributes/' directory but lacks 'contributes/_manifest.md' declaration index.",
                        file_path="contributes/_manifest.md",
                    )
                )
        legacy_fmt_doc = os.path.join(real_dir, "contributes.format.md")
        if os.path.exists(legacy_fmt_doc):
            report.issues.append(
                CheckIssue(
                    severity=CheckSeverity.WARN,
                    category="CONTRIBUTES",
                    message="Legacy 'contributes.format.md' detected. Please migrate to 'contributes/_manifest.md'.",
                    file_path="contributes.format.md",
                )
            )

    def _check_cli_compliance(self, name: str, cli_path: str, report: CheckReport) -> None:
        """
        以 AST 靜態檢核 scripts/cli.py 的合規性：
        1. 必須宣告對應 contributes/core.json 的具名命令函式 def <cmd>(cmd_bags: CmdBags) -> int
        2. 絕對不可有 def main(...) 或舊版 def process(...)
        3. 絕對不可有 if __name__ == '__main__':
        4. 頂層節點除 Docstring、Import、ImportFrom、FunctionDef、ClassDef 外，嚴禁任何未包覆在 func/class 內的執行陳述式。
        """
        try:
            _, tree = self._get_parsed_py(cli_path, filename="scripts/cli.py")
        except Exception as e:
            self._record_syntax_issue(report, os.path.abspath(cli_path), "scripts/cli.py", e)
            return

        declared_funcs, has_main_func, has_if_name_main, invalid_top_level_nodes = _audit_cli_script_ast(tree)

        module_dir = os.path.dirname(os.path.dirname(os.path.abspath(cli_path)))
        cmd_leaves = _collect_declared_cli_commands(module_dir)

        if cmd_leaves:
            missing_cmd_funcs = []
            for full_cmd, primary_cmd in cmd_leaves:
                candidates = {full_cmd.replace("-", "_"), primary_cmd.replace("-", "_")}
                if not any(c in declared_funcs for c in candidates):
                    missing_cmd_funcs.append(full_cmd)
            if missing_cmd_funcs:
                report.issues.append(
                    CheckIssue(
                        severity=CheckSeverity.FAIL,
                        category="STRUCTURE",
                        message=f"Missing required command handler functions in 'scripts/cli.py': {', '.join(missing_cmd_funcs)}.",
                        file_path="scripts/cli.py",
                    )
                )
        else:
            public_handlers = [fn for fn in declared_funcs if not fn.startswith("_") and fn not in ("main", "process")]
            if not public_handlers:
                report.issues.append(
                    CheckIssue(
                        severity=CheckSeverity.FAIL,
                        category="STRUCTURE",
                        message="Missing required command handler function 'def <cmd>(cmd_bags: CmdBags) -> int' in 'scripts/cli.py'.",
                        file_path="scripts/cli.py",
                    )
                )

        if has_main_func:
            report.issues.append(
                CheckIssue(
                    severity=CheckSeverity.FAIL,
                    category="STRUCTURE",
                    message="Forbidden function 'main' found in 'scripts/cli.py'. Module CLI entries must declare command handlers 'def <cmd>(cmd_bags: CmdBags) -> int'.",
                    file_path="scripts/cli.py",
                )
            )

        if has_if_name_main:
            report.issues.append(
                CheckIssue(
                    severity=CheckSeverity.FAIL,
                    category="STRUCTURE",
                    message="Forbidden 'if __name__ == \"__main__\":' execution block found in 'scripts/cli.py'. Module CLI must be purely importable.",
                    file_path="scripts/cli.py",
                )
            )

        for lineno, desc in invalid_top_level_nodes:
            report.issues.append(
                CheckIssue(
                    severity=CheckSeverity.FAIL,
                    category="ANTIPATTERN",
                    message=f"Forbidden {desc} outside function/class at line {lineno} in 'scripts/cli.py'. All executable statements must be enclosed inside functions or classes.",
                    file_path="scripts/cli.py",
                    line_number=lineno,
                )
            )

    _SYS_PATH_MUTATING_METHODS = frozenset({
        "insert",
        "append",
        "extend",
        "remove",
        "pop",
        "clear",
        "sort",
        "reverse",
    })

    @staticmethod
    def _find_sys_path_mutations(tree: ast.AST) -> List[Tuple[int, str]]:
        sys_aliases = {"sys"}
        path_aliases = set()

        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    if alias.name == "sys":
                        sys_aliases.add(alias.asname or "sys")
            elif isinstance(node, ast.ImportFrom) and node.module == "sys":
                for alias in node.names:
                    if alias.name == "path":
                        path_aliases.add(alias.asname or "path")

        def _is_sys_path_expr(expr: ast.AST) -> bool:
            if (
                isinstance(expr, ast.Attribute)
                and expr.attr == "path"
                and isinstance(expr.value, ast.Name)
                and expr.value.id in sys_aliases
            ):
                return True
            if isinstance(expr, ast.Name) and expr.id in path_aliases:
                return True
            return False

        def _is_sys_path_target(target: ast.AST) -> bool:
            if _is_sys_path_expr(target):
                return True
            if isinstance(target, ast.Subscript) and _is_sys_path_expr(target.value):
                return True
            return False

        violations: List[Tuple[int, str]] = []
        seen = set()

        for node in ast.walk(tree):
            lineno = getattr(node, "lineno", 0) or 0
            detail = None
            if (
                isinstance(node, ast.Call)
                and isinstance(node.func, ast.Attribute)
                and node.func.attr in Checker._SYS_PATH_MUTATING_METHODS
                and _is_sys_path_expr(node.func.value)
            ):
                detail = f"sys.path.{node.func.attr}()"
            elif isinstance(node, ast.Assign):
                if any(_is_sys_path_target(t) for t in node.targets):
                    detail = "assignment to sys.path"
            elif isinstance(node, (ast.AnnAssign, ast.AugAssign)):
                if _is_sys_path_target(node.target):
                    detail = "assignment to sys.path"
            elif isinstance(node, ast.Delete):
                if any(_is_sys_path_target(t) for t in node.targets):
                    detail = "deletion on sys.path"

            if detail is not None:
                key = (lineno, detail)
                if key not in seen:
                    seen.add(key)
                    violations.append(key)

        violations.sort(key=lambda item: item[0])
        return violations

    def _check_source_files(self, name: str, real_dir: str, report: CheckReport) -> None:
        for root, dirs, files in os.walk(real_dir):
            dirs[:] = sorted(d for d in dirs if d not in ("__pycache__", ".pytest_cache", ".git"))
            for f in sorted(files):
                if not f.endswith(".py"):
                    continue

                full_p = os.path.join(root, f)
                rel_p = os.path.relpath(full_p, real_dir).replace("\\", "/")
                is_test_file = rel_p.startswith("tests/")

                try:
                    _, tree = self._get_parsed_py(full_p, filename=rel_p)
                except Exception as e:
                    self._record_syntax_issue(report, os.path.abspath(full_p), rel_p, e)
                    continue

                doc_nodes = set()
                if tree.body and isinstance(tree.body[0], ast.Expr) and isinstance(tree.body[0].value, ast.Constant):
                    doc_nodes.add(tree.body[0].value)
                for n in ast.walk(tree):
                    if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                        if n.body and isinstance(n.body[0], ast.Expr) and isinstance(n.body[0].value, ast.Constant):
                            doc_nodes.add(n.body[0].value)

                if name != "core" and not is_test_file:
                    for mut_line, mut_detail in self._find_sys_path_mutations(tree):
                        report.issues.append(
                            CheckIssue(
                                severity=CheckSeverity.FAIL,
                                category="ANTIPATTERN",
                                message=f"Forbidden direct sys.path mutation in '{rel_p}:{mut_line}' ({mut_detail}). Runtime sys.path management must be delegated to 'core.platform'.",
                                file_path=rel_p,
                                line_number=mut_line,
                            )
                        )

                for node in ast.walk(tree):
                    if node in doc_nodes:
                        continue
                    if isinstance(node, ast.ExceptHandler) and node.type is None:
                        lineno = getattr(node, "lineno", None)
                        report.issues.append(
                            CheckIssue(
                                severity=CheckSeverity.WARN,
                                category="ANTIPATTERN",
                                message=f"Bare 'except:' clause detected in '{rel_p}:{lineno or 0}'. Catch 'Exception' or specific exception types instead.",
                                file_path=rel_p,
                                line_number=lineno,
                            )
                        )
                    if isinstance(node, ast.Constant) and isinstance(node.value, str):
                        s_val = node.value
                        lineno = getattr(node, "lineno", None)

                        if name not in ("dev", "core") and not is_test_file:
                            if "module.source://" in s_val:
                                report.issues.append(
                                    CheckIssue(
                                        severity=CheckSeverity.FAIL,
                                        category="PROBING",
                                        message=f"Zero Probing violation: 'module.source://' access detected in '{rel_p}:{lineno}'.",
                                        file_path=rel_p,
                                        line_number=lineno,
                                    )
                                )

                            if s_val in ("config.project.json", "config.local.json"):
                                report.issues.append(
                                    CheckIssue(
                                        severity=CheckSeverity.FAIL,
                                        category="ANTIPATTERN",
                                        message=f"Reinventing the wheel: direct access to '{s_val}' detected in '{rel_p}:{lineno}'. Use 'core.config.get()' / 'core.config.set()' SDK instead.",
                                        file_path=rel_p,
                                        line_number=lineno,
                                    )
                                )
                            elif s_val == "contributes.merged.json":
                                report.issues.append(
                                    CheckIssue(
                                        severity=CheckSeverity.FAIL,
                                        category="ANTIPATTERN",
                                        message=f"Direct contributes probing: access to '{s_val}' detected in '{rel_p}:{lineno}'. Use 'core.contributes.get()' SDK instead.",
                                        file_path=rel_p,
                                        line_number=lineno,
                                    )
                                )

    def _check_test_classes(self, name: str, real_dir: str, report: CheckReport) -> None:
        tests_dir = os.path.join(real_dir, "tests")
        if not os.path.isdir(tests_dir):
            return

        for t_file in sorted(os.listdir(tests_dir)):
            if not (t_file.startswith("test_") and t_file.endswith(".py")):
                continue
            t_full = os.path.join(tests_dir, t_file)
            rel_p = f"tests/{t_file}"
            try:
                _, tree = self._get_parsed_py(t_full, filename=rel_p)
            except Exception as e:
                self._record_syntax_issue(report, os.path.abspath(t_full), rel_p, e)
                continue

            top_level_classes = {n for n in tree.body if isinstance(n, ast.ClassDef)}
            for node in ast.walk(tree):
                if isinstance(node, ast.ClassDef):
                    _verify_test_class_isolation_and_marks(
                        node, t_file, report, is_top_level=(node in top_level_classes)
                    )
                    _check_require_decorator_node(node, t_file, report)
                elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    _check_require_decorator_node(node, t_file, report)

    def _check_sandbox_hooks(self, name: str, real_dir: str, report: CheckReport) -> None:
        hook_path = os.path.join(real_dir, "scripts", "hook.dev.py")
        if not os.path.exists(hook_path):
            return

        rel_p = "scripts/hook.dev.py"
        try:
            _, tree = self._get_parsed_py(hook_path, filename=rel_p)
        except Exception as e:
            self._record_syntax_issue(report, os.path.abspath(hook_path), rel_p, e)
            return

        for node in tree.body:
            if isinstance(node, (ast.Import, ast.ImportFrom, ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    if node.name in ("on_test_setup", "on_test_teardown", "on_module_released", "module_released"):
                        total_args = len(node.args.args) + (1 if node.args.vararg else 0)
                        if total_args < 1:
                            report.issues.append(
                                CheckIssue(
                                    severity=CheckSeverity.FAIL,
                                    category="STRUCTURE",
                                    message=f"Hook function '{node.name}' in {rel_p}:{node.lineno} must accept at least 1 parameter ('context').",
                                    file_path=rel_p,
                                    line_number=node.lineno,
                                )
                            )
            elif isinstance(node, ast.Expr) and isinstance(node.value, ast.Constant) and isinstance(node.value.value, str):
                continue
            elif isinstance(node, ast.Assign):
                continue
            else:
                stmt_type = type(node).__name__
                lineno = getattr(node, "lineno", 0)
                report.issues.append(
                    CheckIssue(
                        severity=CheckSeverity.FAIL,
                        category="ANTIPATTERN",
                        message=f"Forbidden top-level statement '{stmt_type}' in {rel_p}:{lineno}. Hook scripts must only declare imports, functions, or classes.",
                        file_path=rel_p,
                        line_number=lineno,
                    )
                )

    def _check_docs_pollution(self, name: str, real_dir: str, report: CheckReport) -> None:
        docs_dir = os.path.join(real_dir, "docs")
        if not os.path.isdir(docs_dir):
            return

        for root, dirs, files in os.walk(docs_dir):
            dirs[:] = sorted(d for d in dirs if d not in ("__pycache__", ".pytest_cache", ".git"))
            for f in sorted(files):
                if not f.endswith(".md"):
                    continue
                full_p = os.path.join(root, f)
                rel_p = os.path.relpath(full_p, real_dir).replace("\\", "/")
                try:
                    with open(full_p, "r", encoding="utf-8", errors="replace") as df:
                        for lineno, line in enumerate(df, start=1):
                            if "project://source/" in line:
                                report.issues.append(
                                    CheckIssue(
                                        severity=CheckSeverity.WARN,
                                        category="DOCUMENTATION",
                                        message=f"Documentation path pollution: Hardcoded 'project://source/' detected in '{rel_p}:{lineno}'. Downstream developers have no source/ directory; use 'module://<mod>/' semantic URI instead.",
                                        file_path=rel_p,
                                        line_number=lineno,
                                    )
                                )
                except OSError:
                    pass

    def _check_custom_rules(self, name: str, real_dir: str, report: CheckReport) -> None:
        try:
            rules = contributes.get("dev", "custom_checks")
            if not rules or not isinstance(rules, list):
                return
            for rule in rules:
                if not isinstance(rule, dict):
                    continue
                c_func = rule.get("checker_func")
                if not c_func or not isinstance(c_func, str):
                    continue

                donor = None
                func_name = None

                if c_func.startswith("code.func://"):
                    try:
                        donor, _, func_name = parse_code_func_uri(c_func)
                    except Exception as e:
                        report.issues.append(
                            CheckIssue(
                                severity=CheckSeverity.WARN,
                                category="CONTRIBUTES",
                                message=f"Failed to parse custom check URI '{c_func}': {e}",
                                file_path="contributes/core.json",
                            )
                        )
                        continue
                elif ":" in c_func:
                    donor, func_name = c_func.split(":", 1)
                elif "." in c_func:
                    donor, func_name = c_func.rsplit(".", 1)
                else:
                    donor = c_func
                    func_name = "check"

                donor_pkg = donor.split(".")[0]
                donor_candidates = list(dict.fromkeys([
                    donor_pkg,
                    donor_pkg.replace("_", "-"),
                    donor_pkg.replace("-", "_"),
                ]))
                donor_real = None
                priority_mod_name = donor_pkg
                for cand_pkg in donor_candidates:
                    donor_uri = f"module://{cand_pkg}"
                    if vfs.exists(donor_uri):
                        try:
                            donor_real = uri.resolve(donor_uri)
                            priority_mod_name = cand_pkg
                            break
                        except Exception:
                            donor_real = None

                from core.platform import ensure_installed_modules_path, restore_sys_path

                orig_sys_path = list(sys.path)
                try:
                    ensure_installed_modules_path(
                        priority_module=priority_mod_name,
                        extra_paths=[donor_real] if (donor_real and os.path.isdir(donor_real)) else None,
                    )

                    def _import_with_normalized_fallback(mod_target: str) -> Any:
                        try:
                            return importlib.import_module(mod_target)
                        except ModuleNotFoundError:
                            parts = mod_target.split(".")
                            norm_first = parts[0].replace("-", "_")
                            norm_target = ".".join([norm_first] + parts[1:])
                            if norm_target != mod_target:
                                return importlib.import_module(norm_target)
                            alt_first = parts[0].replace("_", "-")
                            alt_target = ".".join([alt_first] + parts[1:])
                            if alt_target != mod_target:
                                return importlib.import_module(alt_target)
                            raise

                    if c_func.startswith("code.func://"):
                        fn = resolve_callable(c_func, use_cache=False)
                    elif "." in c_func and ":" not in c_func:
                        mod_path, fn_name = c_func.rsplit(".", 1)
                        mod = _import_with_normalized_fallback(mod_path)
                        fn = getattr(mod, fn_name)
                    else:
                        mod = _import_with_normalized_fallback(donor)
                        fn = getattr(mod, func_name)

                    if not callable(fn):
                        report.issues.append(
                            CheckIssue(
                                severity=CheckSeverity.WARN,
                                category="CONTRIBUTES",
                                message=f"Custom check '{c_func}' is not callable.",
                                file_path="contributes/core.json",
                            )
                        )
                    else:
                        fn(name, real_dir, report)
                except Exception as e:
                    report.issues.append(
                        CheckIssue(
                            severity=CheckSeverity.WARN,
                            category="CONTRIBUTES",
                            message=f"Failed to execute custom rule '{c_func}': {e}",
                            file_path="contributes/core.json",
                        )
                    )
                finally:
                    restore_sys_path(orig_sys_path)
        except Exception as e:
            report.issues.append(
                CheckIssue(
                    severity=CheckSeverity.WARN,
                    category="CONTRIBUTES",
                    message=f"Failed to load custom checks: {e}",
                    file_path="contributes/core.json",
                )
            )

    def check_all(self) -> Dict[str, CheckReport]:
        return {mod: self.check_module(mod) for mod in discover_source_modules()}


def discover_source_modules(
    target: Optional[str] = None,
    require_manifest: bool = True,
) -> List[str]:
    """
    Scan module.source:// and return sorted valid module names.
    Supports optional target filtering (<mod> or <mod>:<selector>) and manifest.json check.
    """
    src_root_uri = "module.source://"
    if not vfs.exists(src_root_uri):
        return []
    src_real = uri.resolve(src_root_uri)
    if not os.path.isdir(src_real):
        return []

    if target:
        target_mod = target.split(":", 1)[0] if ":" in target else target
        mod_path = os.path.join(src_real, target_mod)
        if os.path.isdir(mod_path) and (not require_manifest or os.path.isfile(os.path.join(mod_path, "manifest.json"))):
            return [target_mod]
        return []

    modules: List[str] = []
    for item in sorted(os.listdir(src_real)):
        if item.startswith("."):
            continue
        mod_path = os.path.join(src_real, item)
        if os.path.isdir(mod_path) and (not require_manifest or os.path.isfile(os.path.join(mod_path, "manifest.json"))):
            modules.append(item)
    return modules
