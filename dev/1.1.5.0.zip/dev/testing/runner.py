"""
Test discovery, execution engine and ASCII report formatter for YS-Codebase.
"""
import atexit
import os
import subprocess
import sys
import threading
import time
import unittest
from io import StringIO
from typing import List, Dict, Any, Optional, Set, Tuple
from core import uri, vfs
from core.context import get_runtime_context
from core.platform.process import is_process_alive, kill_process_tree, reap_sandbox_processes, terminate_popen_tree
from dev.checker import discover_source_modules
from dev.testing.contract import make_contract_suite
from dev.testing.case import YSCBTestCase
from dev.testing.requirement import Requirement

_CATEGORY_MASK = (
    Requirement.WORKFLOW.value
    | Requirement.PERF.value
    | Requirement.ENV.value
    | Requirement.NETWORK.value
    | Requirement.LOGIC.value
)

_ACTIVE_POPEN_LOCK = threading.Lock()
_ACTIVE_POPEN_STATE_KEY = "dev.runner.active_popen_procs"
_HOOKS_INSTALLED_STATE_KEY = "dev.runner.cleanup_hooks_installed"


def _get_active_popen_set() -> Set[subprocess.Popen]:
    return get_runtime_context().get_module_state(_ACTIVE_POPEN_STATE_KEY, set)


def cleanup_active_test_subprocesses() -> int:
    """Terminates all tracked child subprocesses spawned by `run_subprocess_with_tree_timeout`."""
    with _ACTIVE_POPEN_LOCK:
        proc_set = _get_active_popen_set()
        active = list(proc_set)
        proc_set.clear()
    reaped = 0
    for proc in active:
        try:
            if proc.poll() is None:
                terminate_popen_tree(proc, timeout_sec=1.5)
                reaped += 1
        except Exception:
            pass
    return reaped


def _install_runner_cleanup_hooks() -> None:
    """Registers `atexit` once to reap active child subprocesses."""
    with _ACTIVE_POPEN_LOCK:
        ctx = get_runtime_context()
        if bool(ctx.get_module_state(_HOOKS_INSTALLED_STATE_KEY, lambda: False)):
            return
        ctx.set_module_state(_HOOKS_INSTALLED_STATE_KEY, True)

    atexit.register(cleanup_active_test_subprocesses)


def start_parent_death_watchdog(expected_ppid: int) -> threading.Event:
    """
    Spawns a daemon watchdog thread inside `dev op-test` that monitors `expected_ppid`
    (and `os.getppid() == 1`) and reaps the sandbox process tree if the parent test harness dies.
    """
    stop_event = threading.Event()
    if expected_ppid <= 1:
        return stop_event

    def _watchdog_loop() -> None:
        while not stop_event.wait(1.0):
            curr_ppid = os.getppid() if hasattr(os, "getppid") else expected_ppid
            if curr_ppid == 1 or not is_process_alive(expected_ppid):
                try:
                    cleanup_active_test_subprocesses()
                    sb_dir = os.environ.get("YSCB_SANDBOX_DIR", "")
                    if sb_dir and os.path.isdir(sb_dir):
                        reap_sandbox_processes(sb_dir, timeout_sec=1.0)
                    kill_process_tree(os.getpid(), timeout_sec=1.0)
                except Exception:
                    pass
                break

    threading.Thread(
        target=_watchdog_loop,
        daemon=True,
        name="dev-op-test-parent-watchdog",
    ).start()
    return stop_event


def run_subprocess_with_tree_timeout(
    cmd: List[str],
    timeout_sec: float = 30.0,
    cwd: Optional[str] = None,
    env: Optional[Dict[str, str]] = None,
) -> Tuple[int, str, str]:
    """
    Executes a child subprocess in its own process group/session and terminates the entire
    process tree on timeout or parent termination, preventing orphaned grandchildren from
    holding stdout/stderr pipes open or surviving as `PPID=1` zombies.
    """
    _install_runner_cleanup_hooks()
    popen_kwargs: Dict[str, Any] = {"close_fds": True}
    if sys.platform == "win32":
        flags = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0x00000200) | getattr(
            subprocess, "CREATE_NO_WINDOW", 0x08000000
        )
        popen_kwargs["creationflags"] = flags
    else:
        popen_kwargs["start_new_session"] = True

    proc = subprocess.Popen(
        cmd,
        cwd=cwd,
        env=env,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        encoding="utf-8",
        errors="replace",
        **popen_kwargs,
    )
    with _ACTIVE_POPEN_LOCK:
        _get_active_popen_set().add(proc)
    try:
        out, err = proc.communicate(timeout=timeout_sec)
        return proc.returncode or 0, out or "", err or ""
    except subprocess.TimeoutExpired:
        terminate_popen_tree(proc, timeout_sec=2.0)
        try:
            out, err = proc.communicate(timeout=2.0)
        except Exception:
            out, err = "", ""
        return -1, out or "", (err or "") + f"\n[dev:runner] Process timed out after {timeout_sec}s"
    finally:
        with _ACTIVE_POPEN_LOCK:
            _get_active_popen_set().discard(proc)
        if proc.poll() is None:
            terminate_popen_tree(proc, timeout_sec=2.0)
        for pipe in (proc.stdout, proc.stderr):
            if pipe:
                try:
                    pipe.close()
                except Exception:
                    pass


def filter_suite(
    suite: unittest.TestSuite,
    pattern: Optional[str] = None,
    test_type: Optional[str] = None,
    target: Optional[str] = None,
) -> unittest.TestSuite:
    """
    Recursively filter test cases within a TestSuite tree by pattern, target selector, and 4-tier taxonomy.
    """
    filtered = unittest.TestSuite()

    resolved_types = set()
    if test_type:
        tt = test_type.lower().replace("-", "_")
        if tt in ("logic", "logical"):
            resolved_types = {"logic"}
        elif tt == "env":
            resolved_types = {"env"}
        elif tt == "network":
            resolved_types = {"network"}
        elif tt == "workflow":
            resolved_types = {"workflow"}
        elif tt == "perf":
            resolved_types = {"perf"}
        elif tt in ("all", "all_types"):
            resolved_types = {"logic", "env", "workflow", "perf", "network"}

    if not resolved_types:
        resolved_types = {"logic", "env", "network"}

    def _matches(test_case: unittest.TestCase) -> bool:
        method_name = getattr(test_case, "_testMethodName", "")
        class_name = test_case.__class__.__name__
        module_name = test_case.__class__.__module__
        full_id = f"{module_name}.{class_name}.{method_name}"

        if target:
            t_clean = (target.split(":", 1)[1] if ":" in target else target).strip()
            if t_clean:
                t_clean_lower = t_clean.lower()
                if (
                    t_clean_lower not in full_id.lower()
                    and t_clean_lower not in method_name.lower()
                    and t_clean_lower not in class_name.lower()
                ):
                    return False
                if pattern and (pattern.lower() not in method_name.lower() and pattern.lower() not in class_name.lower()):
                    return False
                if class_name == "_FailedTest" or test_type is None:
                    return True
                return get_test_category(test_case) in resolved_types

        if pattern and (pattern.lower() not in method_name.lower() and pattern.lower() not in class_name.lower()):
            return False

        if class_name == "_FailedTest":
            return True

        category = get_test_category(test_case)
        return category in resolved_types

    def _recurse(node: Any) -> None:
        if isinstance(node, unittest.TestSuite):
            for sub in node:
                _recurse(sub)
        elif isinstance(node, unittest.TestCase):
            if _matches(node):
                filtered.addTest(node)

    _recurse(suite)
    return filtered


class TestDiscovery:
    @staticmethod
    def discover_modules(target: Optional[str] = None) -> List[str]:
        return discover_source_modules(target=target, require_manifest=True)

    @staticmethod
    def build_suite_for_module(
        module_name: str,
        test_type: Optional[str] = None,
        pattern: Optional[str] = None,
        target: Optional[str] = None,
        contract_only: bool = False,
    ) -> Tuple[unittest.TestSuite, int, int]:
        """
        Builds a two-phase test suite for module:
        Phase 1: Universal Auto-Contract Suite
        Phase 2: Custom tests in source/<mod>/tests/ (if present and not contract_only)
        Returns (suite, contract_count, custom_count)
        """
        master_suite = unittest.TestSuite()
        effective_target = None if target == module_name else target

        contract_suite = make_contract_suite(module_name)
        if pattern or test_type or effective_target:
            contract_suite = filter_suite(contract_suite, pattern=pattern, test_type=test_type, target=effective_target)
        contract_count = contract_suite.countTestCases()
        master_suite.addTests(contract_suite)

        custom_count = 0
        if not contract_only:
            src_real = uri.resolve(f"module.source://{module_name}")
            tests_dir = os.path.join(src_real, "tests")
            if os.path.isdir(tests_dir):
                pkg_name = "ast_engine" if module_name == "ast" else module_name.replace("-", "_")
                mods_map = sys.modules
                for mod_k in list(mods_map.keys()):
                    if mod_k in ("core", "dev.testing") or mod_k.startswith(("core.", "dev.testing.")):
                        continue
                    if (
                        mod_k == "tests"
                        or mod_k.startswith("tests.")
                        or mod_k == "scripts"
                        or mod_k.startswith("scripts.")
                        or mod_k == pkg_name
                        or mod_k.startswith(f"{pkg_name}.")
                    ):
                        mods_map.pop(mod_k, None)

                try:
                    src_root = uri.resolve("module.source://")
                except Exception:
                    src_root = None

                from core.platform import activate_test_module_source_path

                activate_test_module_source_path(src_real, src_root=src_root)

                init_py = os.path.join(tests_dir, "__init__.py")
                if not os.path.isfile(init_py):
                    try:
                        with open(init_py, "w", encoding="utf-8") as f:
                            f.write('"""Test package auto-infill."""\n')
                    except OSError:
                        pass

                loader = unittest.TestLoader()
                discovered = loader.discover(start_dir=tests_dir, pattern="test_*.py", top_level_dir=src_real)

                def _validate_test_types(node: Any) -> None:
                    if isinstance(node, unittest.TestSuite):
                        for sub in node:
                            _validate_test_types(sub)
                    elif isinstance(node, unittest.TestCase):
                        if node.__class__.__name__ == "_FailedTest":
                            return
                        mro_names = [b.__name__ for b in node.__class__.__mro__]
                        if "YSCBTestCase" not in mro_names:
                            raise TypeError(
                                f"[dev:test] Security Guard Blocked: Test class '{node.__class__.__name__}' directly subclasses 'unittest.TestCase'. "
                                f"All YSCB tests MUST inherit from 'dev.testing.case.YSCBTestCase' to prevent sandbox leakage."
                            )

                _validate_test_types(discovered)
                discovered = filter_suite(discovered, pattern=pattern, test_type=test_type, target=effective_target)
                custom_count = discovered.countTestCases()
                master_suite.addTests(discovered)

        return master_suite, contract_count, custom_count


def get_test_category(test_case: unittest.TestCase) -> str:
    """Extract semantic category string ('logic', 'env', 'workflow', 'perf', 'network') from TestCase."""
    method_name = getattr(test_case, "_testMethodName", "")
    method = getattr(test_case, method_name, None) if method_name else None
    method_req = getattr(method, "__requirement__", None) if method else None
    class_req = getattr(test_case.__class__, "__requirement__", None)
    if class_req is None:
        class_req = getattr(test_case, "__requirement__", None)

    method_val = (method_req.value if hasattr(method_req, "value") else int(method_req)) if method_req is not None else 0
    class_val = (class_req.value if hasattr(class_req, "value") else int(class_req)) if class_req is not None else 0
    req_val = method_val if (method_req is not None and (method_val & _CATEGORY_MASK) != 0) else class_val

    if req_val:
        if bool(req_val & Requirement.WORKFLOW.value):
            return "workflow"
        if bool(req_val & Requirement.PERF.value):
            return "perf"
        if bool(req_val & Requirement.ENV.value):
            return "env"
        if bool(req_val & Requirement.NETWORK.value):
            return "network"
        if bool(req_val & Requirement.LOGIC.value):
            return "logic"
    return "logic"


class OutputCapturer:
    """Context manager for buffering stdout and stderr during test execution."""
    _ACTIVE_INSTANCE: Optional["OutputCapturer"] = None

    def __init__(self, enabled: bool = True):
        self.enabled = enabled
        self._stdout_buf = StringIO()
        self._stderr_buf = StringIO()
        self._orig_stdout: Optional[Any] = None
        self._orig_stderr: Optional[Any] = None

    def __enter__(self) -> "OutputCapturer":
        if self.enabled:
            OutputCapturer._ACTIVE_INSTANCE = self
            self._orig_stdout = sys.stdout
            self._orig_stderr = sys.stderr
            sys.stdout = self._stdout_buf
            sys.stderr = self._stderr_buf
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        if self.enabled:
            if OutputCapturer._ACTIVE_INSTANCE is self:
                OutputCapturer._ACTIVE_INSTANCE = None
            if self._orig_stdout is not None:
                sys.stdout = self._orig_stdout
            if self._orig_stderr is not None:
                sys.stderr = self._orig_stderr

    def snapshot_offsets(self) -> Tuple[int, int]:
        return (len(self._stdout_buf.getvalue()), len(self._stderr_buf.getvalue()))

    def get_slice(self, start_offsets: Tuple[int, int]) -> str:
        out_start, err_start = start_offsets
        out_part = self._stdout_buf.getvalue()[out_start:]
        err_part = self._stderr_buf.getvalue()[err_start:]
        return (out_part + err_part).strip()

    def get_output(self) -> str:
        return (self._stdout_buf.getvalue() + self._stderr_buf.getvalue()).strip()


def _format_failure_entries(failures_list: List[Dict[str, Any]]) -> List[str]:
    lines: List[str] = []
    for item in failures_list:
        m_tag = f"[{item.get('module', 'unknown')}]"
        t_type = item.get("type", "FAIL")
        t_name = item.get("test", "unknown")
        t_msg = item.get("message", "")
        t_loc = item.get("location", "")
        t_re_run = item.get("rerun", "")
        captured = item.get("captured_output", "")

        lines.append(f"  [!] {m_tag:<10} {t_type:<8} {t_name}")
        if t_msg:
            lines.append(f"      |-- Message:  {t_msg}")
        if t_loc:
            lines.append(f"      |-- Location: {t_loc}")
        if captured:
            cap_lines = captured.splitlines()
            if len(cap_lines) > 20:
                cap_snippet = "\n          ".join(cap_lines[:10] + ["... [truncated] ..."] + cap_lines[-5:])
            else:
                cap_snippet = "\n          ".join(cap_lines)
            lines.append(f"      |-- Output:\n          {cap_snippet}")
        if t_re_run:
            lines.append(f"      \\-- Quick Re-run: {t_re_run}")
        else:
            lines.append(f"      \\-- Quick Re-run: python yscb.py dev test --target={item.get('module')}:{t_name}")
    return lines


class ASCIIReportFormatter:
    @staticmethod
    def format_summary(report_data: Dict[str, Any], warnings_count: int = 0) -> str:
        lines = [
            "=" * 70,
            "YS-Codebase Test Execution Diagnostic Report",
            "=" * 70,
        ]

        filter_mode = report_data.get("filter_mode", "Default (LOGIC + ENV)")
        target_scope = report_data.get("target_scope", "All")
        no_build = report_data.get("no_build", False)
        build_str = "No-build (Fast)" if no_build else "Hermetic Build"
        lines.append(f"[*] Mode: {filter_mode} | Target: {target_scope} | Build: {build_str}")
        if warnings_count > 0:
            lines.append(f"[*] Notices: {warnings_count} sandbox warning(s) captured (suppressed, run with --verbose to inspect)")
        lines.append("-" * 70)

        for mod_info in report_data.get("modules", []):
            mod_name = mod_info["name"]
            mod_dur = mod_info.get("duration", 0.0)
            status_str = "[PASS]" if mod_info["passed"] else "[FAIL]"
            header_left = f"[*] Module: {mod_name} ({mod_dur:.2f}s)"
            lines.append(f"{header_left:<50} {status_str:>19}")
            lines.append(f"    |-- [Contract] Auto-Contract Suite ... ({mod_info['contract_passed']}/{mod_info['contract_total']})")

            if mod_info["custom_total"] > 0:
                tax_parts = []
                if mod_info.get("logic_passed", 0) > 0:
                    tax_parts.append(f"Logic: {mod_info['logic_passed']}")
                if mod_info.get("env_passed", 0) > 0:
                    tax_parts.append(f"Env: {mod_info['env_passed']}")
                if mod_info.get("workflow_passed", 0) > 0:
                    tax_parts.append(f"Workflow: {mod_info['workflow_passed']}")
                if mod_info.get("perf_passed", 0) > 0:
                    tax_parts.append(f"Perf: {mod_info['perf_passed']}")
                if mod_info.get("unknown", 0) > 0:
                    tax_parts.append(f"Unknown: {mod_info['unknown']}")
                tax_str = f" [{', '.join(tax_parts)}]" if tax_parts else ""
                lines.append(f"    \\-- [Custom]   Custom Tests ........... ({mod_info['custom_passed']}/{mod_info['custom_total']}){tax_str}")
            else:
                lines.append("    \\-- [Custom]   Custom Tests ........... (No custom tests)")

            if mod_info.get("errors"):
                for err in mod_info["errors"]:
                    lines.append(f"        [!] ERROR: {err}")

        failures_list = report_data.get("failures_list", [])
        if failures_list:
            lines.append("-" * 70)
            lines.append("FAILED / ERROR TEST CASES LIST:")
            lines.extend(_format_failure_entries(failures_list))

        lines.append("-" * 70)
        total = report_data.get("total", 0)
        passed = report_data.get("passed", 0)
        failed = report_data.get("failed", 0)
        unknown = report_data.get("unknown", 0)
        skipped = report_data.get("skipped", 0)
        duration = report_data.get("duration", 0.0)
        overall = "PASSED (100% Ready)" if (failed == 0 and unknown == 0) else "FAILED"
        if unknown > 0:
            lines.append(f"Summary : {total} Total, {passed} Passed, {failed} Failed, {unknown} Unknown, {skipped} Skipped ({duration:.3f}s)")
        else:
            lines.append(f"Summary : {total} Total, {passed} Passed, {failed} Failed, {skipped} Skipped ({duration:.3f}s)")
        lines.append(f"Status  : {overall}")
        lines.append("=" * 70)
        return "\n".join(lines)

    @staticmethod
    def format_throttled(report_data: Dict[str, Any]) -> str:
        """
        將測試報告數據轉換為最大化節省 Token 的節流格式。
        - 全數通過: "Pass: {passed}({pct:.1f}%), Fail: 0, Skip: {skipped}" (有 unknown 時附加 Unknown: {unknown})
        - 存在失敗: 統計首行 + FAILED / ERROR TEST CASES LIST 詳情
        """
        total = report_data.get("total", 0)
        passed = report_data.get("passed", 0)
        failed = report_data.get("failed", 0)
        unknown = report_data.get("unknown", 0)
        skipped = report_data.get("skipped", 0)
        pct = (passed / total * 100.0) if total > 0 else 0.0

        if unknown > 0:
            stat_line = f"Pass: {passed}({pct:.1f}%), Fail: {failed}, Unknown: {unknown}, Skip: {skipped}"
        else:
            stat_line = f"Pass: {passed}({pct:.1f}%), Fail: {failed}, Skip: {skipped}"

        failures_list = report_data.get("failures_list", [])
        if failed == 0 and not failures_list:
            return stat_line

        fail_lines = [stat_line, "", "-" * 70, "FAILED / ERROR TEST CASES LIST:"]
        if failures_list:
            fail_lines.extend(_format_failure_entries(failures_list))
        else:
            for mod_info in report_data.get("modules", []):
                for err in mod_info.get("errors", []):
                    fail_lines.append(f"  [!] [{mod_info.get('name', 'unknown')}] ERROR: {err}")

        fail_lines.append("-" * 70)
        return "\n".join(fail_lines)


class SafeStreamWriter:
    """Stream wrapper that handles Unicode encoding errors gracefully on Windows console."""
    def __init__(self, target: Any):
        self.target = target

    def write(self, s: str) -> None:
        try:
            self.target.write(s)
        except UnicodeEncodeError:
            enc = getattr(self.target, "encoding", None) or "utf-8"
            safe_s = s.encode(enc, errors="replace").decode(enc, errors="replace")
            self.target.write(safe_s)

    def flush(self) -> None:
        try:
            self.target.flush()
        except Exception:
            pass

    def __getattr__(self, name: str) -> Any:
        return getattr(self.target, name)


class TestRunner:
    def __init__(self, verbose: bool = False, keep_sandbox: bool = False):
        self.verbose = verbose
        self.keep_sandbox = keep_sandbox

    def run_suite(self, suite: unittest.TestSuite) -> Tuple[unittest.TestResult, str]:
        get_runtime_context().set_module_state("dev.testing.keep_sandbox", bool(self.keep_sandbox))

        stream = SafeStreamWriter(sys.stdout) if self.verbose else StringIO()
        runner = unittest.TextTestRunner(stream=stream, verbosity=2 if self.verbose else 0)
        capturer = OutputCapturer(enabled=not self.verbose)
        try:
            with capturer:
                result = runner.run(suite)
            return result, capturer.get_output()
        finally:
            try:
                YSCBTestCase.cleanup_shared_sandbox()
            except Exception:
                pass
