# Phase 2: 架構設計 (P02 Architecture Plan Guide)

本手冊定義 Phase 2 架構設計階段之拓撲設計、時序圖規範與 Test-First 測試初始化要求。

```markdown
Phase 02 執行檢核表：
- [ ] 1. 讀取 P01_requirements_spec.md，確認所有 FR/EC/NFR 皆有對應架構組件承接
- [ ] 2. 依 P02_architecture_plan.md 模板撰寫架構設計與關鍵決策 [P02:DR-XX]
- [ ] 3. [!] 同步讀取 P06_test_plan.md 模板，初始化測試計畫草案 (狀態設為 Draft)，預先映射 FT-XX / ET-XX / RT-XX
- [ ] 4. 更新 changelog.md，呈遞 P02 狀態卡並立即 End Turn
```

---

## 1. 核心定位與職責

- **模組邊界與職責劃分**：定義組件職責，確立依賴單向性，杜絕循環依賴。
- **破壞性簽名變更之強制 `callers` 守門 (`Mandatory Callers Gate`)**：凡涉及移除、重命名或修改既有公開類別、建構子、方法、屬性或事件簽名時，在填寫 `P02_architecture_plan.md` §3「受影響檔案與新建檔案清單」前，**強制必須對每個受影響符號執行 `python __${yscb.host://yscb.py}__ knowledge-db callers <Symbol> --json`**（涵蓋生產源碼、測試與沙盒/範例空間），確保 100% 靜態盤點所有跨模組調用端，嚴禁憑記憶列舉導致後期編譯返工。
- **動態流程設計**：以循序圖或資料管線流向圖清晰表達跨物件協同機制。
- **Test-First 測試預先映射**：在架構確立的同時，同步預先規劃測試案例。

---

## 2. 架構設計與圖表規範

- **圖表排版優先級**：
  $$\text{Markdown 表格} \succ \text{垂直 Mermaid (TD / TB)} \succ \text{橫向 Mermaid (LR)} \succ \text{純文字 ASCII 表格}$$
- **Mermaid 防呆**：節點標籤若含括號或特殊符號，強制使用引號包覆（例 `id["Label (Info)"]`）。
- **關鍵決策標註 ([P02:DR-XX])**：記錄選型、狀態空間定義與快取一致性等關鍵決策。

---

## 3. `P06_test_plan.md` (Draft) 同步初始化鐵律

在 Phase 2 完成時，**必須同步建立並初始化 `P06_test_plan.md`（狀態：`Draft`）**：
- 將 `P01` 定義之 `FR-XX` 映射至 `FT-XX`（功能測試）。
- 將 `P01` 定義之 `EC-XX` 映射至 `ET-XX`（邊界測試）。
- 規劃系統全量回歸測試 `RT-01`。
- **CLI 自癒與免讀日誌追加**：撰寫完 `P02_architecture_plan.md` 後，可直接執行 `python __${yscb.host://yscb.py}__ agents-workflow plan verify [plan_name] --phase P02 --log "完成 P02 架構設計與 P06 Draft 初始化" --model "<ModelName>"`（若尚未手動建立 `P06_test_plan.md`，工具鏈將於 `P02` 檢核通過時自動依據 `P01` 需求 ID 初始化 `P06_test_plan.md (Draft)` 並免讀追加 `changelog.md`）。

`__@{PHASE02_AGENTS_GUIDE}__`

---

## [!] 4. Phase 2 結束 Checkpoint

- **極精簡 Session 回覆格式**：產出 `P02_architecture_plan.md` 與 `P06_test_plan.md` (Draft) 並更新 `changelog.md` 後，對話中**嚴禁全文重複、傾倒圖表或冗長轉述**，強制僅呈遞以下極簡卡片：
  ```markdown
  ###  P02 架構設計已落檔
  - **產出文件**：[P02_architecture_plan.md](__${project://plans/}__/{plan_name}/P02_architecture_plan.md)、[P06_test_plan.md](__${project://plans/}__/{plan_name}/P06_test_plan.md) (Draft)
  - **架構摘要**：[1~2 行組件邊界 / 核心決策 [P02:DR-XX] / FT & ET 測試預排 N 項]
  - **待確認事項**：請問是否同意架構設計並推進至 Phase 3（API 規格）？
  ```
- **立即 End Turn 等待確認**：嚴禁跨階段連續產出。

