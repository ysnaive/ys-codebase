# Phase 0: 需求討論與邊界釐清 (P00 Discuss Guide)

本手冊定義 Full Track / Research 計畫 Phase 0 階段之角色職責、討論防呆與 JIT 延遲建檔規範。

---

## 1. 核心定位與職責

- **角色定位**：扮演技術顧問與架構把關者，主動向開發者釐清模糊邊界，挖掘隱含需求與相依風險。
- **零臆測防呆**：
  - 面對抽象或寬泛指令（例「優化某模組」），**嚴禁主動發散腦補具體需求清單**；必須反問「請問具體的優化目標與期望範圍為何？」。
  - 唯有在開發者明確指示「幫我分析/評估」時，方可開展候選方案與架構對比。

---

## 2. JIT 延遲建檔與分流守門

1. **對話先行**：輸入 [/new-plan](`__#{module://agents-workflow/assets/skills/new-plan/SKILL.md}__`) 時不立即建立實體目錄，先於對話中進行深入探討。
2. **確立分流伴隨建檔**：與開發者充分討論並確認分流類型後，伴隨建立計畫目錄並產出對應初始文件（`P00_discuss.md`、`fast_track_plan.md` 或 `revision_log.md`）與 `changelog.md`。
3. **調研或討論無痛轉入修訂**：若前置討論 (`P00`) 或調研 (`R{NN}_{topic}.md`) 收斂後確認僅涉及非業務邏輯之 UI/UX/DX、參數或文檔微調，可直接於同計畫目錄建立 `revision_log.md` 進入修訂計畫。
4. **調研無痛升級**：若需求過於複雜或未知技術過多，主動建議先入調研計畫（產出 `R{NN}_{topic}.md` 後可無縫升級）。

---

## 3. `P00_discuss.md` 產出核心規範

- **背景與動機**：記錄問題痛點、系統現狀與業務價值。
- **需求釐清清單**：記錄問答記錄，確保雙方對邊界達成 100% 共識。
- **架構影響範圍**：預判涉及之模組、資料流轉向與介面相容性。
- **關鍵架構決策 ([P00:DR-XX])**：記錄已拍板定案之核心技術方案。

---

`__@{PHASE00_AGENTS_GUILD}__`

---

## [!] 4. Phase 0 結束 Checkpoint

- **極精簡 Session 回覆格式**：產出 `P00_discuss.md` 與 `changelog.md` 後，對話中**嚴禁全文重複或冗長轉述**，強制僅呈遞以下極簡卡片：
  ```markdown
  ###  P00 需求討論與分流確認
  - **產出文件**：[P00_discuss.md](__${project://plans/}__/{plan_name}/P00_discuss.md)、[changelog.md](__${project://plans/}__/{plan_name}/changelog.md)
  - **推薦分流**：[Full Track | Fast Track | Umbrella | Revision | Research]
  - **核心決策**：[1~2 行關鍵架構定案或主要 [P00:DR-XX]]
  - **待確認事項**：請問是否同意此分流並推進至下一階段？
  ```
- **立即 End Turn 等待確認**：嚴禁跨階段連續產出。

