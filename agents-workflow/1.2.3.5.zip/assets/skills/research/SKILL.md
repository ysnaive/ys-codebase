---
name: research
description: 針對高複雜度技術命題與多候選方案執行優劣權衡與可行性驗證，產出 R{NN}_{topic}.md 調研報告與三出口建議卡。觸發情境：輸入 /research，或要求對技術選型與架構方案進行深度調研評估。
---

# 深度技術調研工作流 (Research)

本工作流用於高複雜度、新技術選型、演算法可行性或架構演進之深度論證與客觀對比。執行規範遵循 [development-sop](`__#{module://agents-workflow/assets/skills/development-sop/SKILL.md}__`)。

> [!NOTE]
> **邊界轉交說明**：若方案已明確、屬於日常功能編碼實作，請直接遵循 [development-sop](`__#{module://agents-workflow/assets/skills/development-sop/SKILL.md}__`)；若為開發或測試中途之異常排查，請改走 [`/discuss`](`__#{module://agents-workflow/assets/skills/discuss/SKILL.md}__`)。

---

## 核心原則與雙軌生命週期

1. **僅被動觸發（Explicit / Requested Only）**：獨立前置調研僅在開發者提出探討需求或下達顯式指令（如 `/research [主題]`）時進行，嚴禁在一般功能開發中途擅自發起。
2. **雙軌生命週期（記憶體收斂 -> 實體落檔）**：
   - **獨立前置調研**：未開立計畫前，隨問隨答與方案對比保留於對話與快取中，不主動在磁碟建檔。
   - **正式固化建檔**：開發者指示立項或需正式留痕時，寫入計畫目錄下的 `R{NN}_{topic}.md`（如 `R01_architecture_reference.md`）。
3. **免除死板模板束縛與客觀證據導向**：依標準模板 [`RXX_research_report.md`](`__#{module://agents-workflow/assets/templates/RXX_research_report.md}__`) 建立，維持標準元數據標頭，正文依主題自由排版論述，並聚焦客觀架構取捨（Trade-offs）與數據驗證。
4. **標準命名前綴**：調研報告統一採用 `R{NN}_{topic}.md`。

---

## 執行步驟

開始執行時，請依序遵循以下檢核步驟：

```markdown
/research 專題調研檢核表：
- [ ] 步驟 1：盤點核心問題、調研目標與評估維度（若計畫目錄未建立則依 JIT 原則初始化）
- [ ] 步驟 2：依主題性質展開深度剖析、方案對比或實證數據收集
- [ ] 步驟 3：讀取 RXX_research_report.md 模板，產出 R{NN}_{topic}.md 並更新 changelog.md
- [ ] 步驟 4：呈遞極簡調研卡與三大出口分流建議，並立即 End Turn 等待裁決
```

### 步驟 1：盤點核心調研維度
與開發者梳理本次調研攻堅的具體核心問題、評估指標與技術邊界。

---

### 步驟 2：深度分析與客觀評估 (含 Subagent 支柱一委派協定)
依調研主題性質（技術選型、演算法/機制研究、市場/生態系調研或量化對照）展開客觀探討：
- 若屬多方案選型，橫向比對具代表性的候選方案，客觀分析優缺點 (Pros & Cons)、資源代價與潛在坑點；若屬純機制研究、市場調研或數據分析，則聚焦客觀證據與深度剖析，無須強湊候選方案表。
- 結合專案現況給出客觀分析，嚴禁主觀吹捧。
- **[!] 支柱一：唯讀廣域探索隔離 (Pillar 1 Delegation)**：
  - 單一領域或局部機制預設由主代理 Inline 檢索；當調研**橫跨多個外部模組、多個正交類別（Classes）或海量文檔**，或需執行無預設假設探索時，遵循 [`BlindSubagentStandards.md`](`__#{module://agents-workflow/assets/standards/BlindSubagentStandards.md}__`) 原型 ①（套用 `§5.2` 盲眼派發模板與 `Mode I` 150~300 Tokens 濃縮回傳契約；無子代理環境自動降級）委派唯讀 Subagent 進行獨立探索。

---

### 步驟 3：產出專題調研報告 (`R{NN}_{topic}.md`)
若需正式落檔，讀取標準模板 [`RXX_research_report.md`](`__#{module://agents-workflow/assets/templates/RXX_research_report.md}__`)，填寫真實標頭與 `> 模型：`（依模型紀錄規則）後落檔（獨立調研計畫須伴隨 `P00_discuss.md` 與 `changelog.md`）：
1. 標準元數據標頭（含 `> 模型：`）。
2. `## 1. 背景與調研目標`：梳理背景脈絡、核心問題與調研範疇。
3. `## 2. 核心分析與評估`：依主題自由組織子章節（候選方案對比矩陣、架構/機制剖析、PoC 驗證或量化數據）。
4. `## 3. 結論`：總結客觀結論（若有落地或流轉建議可一併附上；純研究則總結核心洞察即可）。

`__@{RESEARCH_AGENTS_GUIDE}__`

---

### 步驟 4：呈遞極簡調研卡與三大出口分流 (強制 End Turn)

對話 Session **嚴禁全文重複、圖表傾倒或代碼傾倒**，強制僅呈遞以下極簡調研卡，並**立即 End Turn 等待確認**：

```markdown
### 🔬 R01 調研報告已落檔
- **產出文件**：[R01_{topic}.md](`__${project://plans}__/{plan_name}/R01_{topic}.md`)、[changelog.md](`__${project://plans}__/{plan_name}/changelog.md`)
- **調研主題**：[1 行調研核心命題]
- **調研結論**：[1~2 行方案選型評估結論 / 推薦採納方案]
- **推薦出口**：
  1. 出口 ① 立即實作：轉入 [/new-plan](`__#{module://agents-workflow/assets/skills/new-plan/SKILL.md}__`) 或原地追加 P01~P07 升級實作計畫
  2. 出口 ② 路線圖儲備：轉入 [/roadmap](`__#{module://agents-workflow/assets/skills/roadmap/SKILL.md}__`) 納入長期演進儲備（日後以 `roadmap promote` 消耗立項）或轉入 [/todo](`__#{module://agents-workflow/assets/skills/todo/SKILL.md}__`) 記錄微觀待辦
  3. 出口 ③ 放棄結案：方案不可行或成本過高，記錄原因後於調研報告標記 Concluded 登記結案
- **待確認事項**：請問是否採納此結論，並選擇何種流轉出口？
```

> [!IMPORTANT]
> **出口拍板狀態閉環**：開發者拍板任一出口（①、②、③）時，均須先將 `R{NN}_{topic}.md` 標頭狀態更新為 `Concluded` 再執行流轉；出口 ③ 同步將 `P00_discuss.md` 標記為 `Confirmed` / `Completed`。

---

## 常見踩坑指南 (Gotchas)

- **切勿在對話視窗直接貼出數百行報告取代落檔**：正式調研成果必須寫入 `R{NN}_{topic}.md` 實體檔案（SSOT），對話僅輸出上方摘要卡片。
- **未獲開發者選定出口前切勿自行展開 `P01` 實作**：調研結束後有三大可能出口，必須等待開發者拍板選擇出口 ① 後，才能啟動 `Phase 01` 規格轉譯。
