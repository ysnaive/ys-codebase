"""
Scaffolder implementation for YS-Codebase modules.
"""
import os
import re
from typing import Tuple
from core import uri

class Scaffolder:
    def __init__(self):
        pass

    def create_module(self, name: str, description: str = "", author: str = "", desc: str = "") -> Tuple[bool, str]:
        if not name:
            return False, "Module name cannot be empty."
        
        if not re.match(r"^[a-zA-Z0-9_][a-zA-Z0-9_-]*$", name):
            return False, f"Invalid module name '{name}'. Module name must contain only alphanumeric characters, underscores, or hyphens."
        
        target_src_uri = f"module.source://{name}"
        if uri.exists(target_src_uri):
            return False, f"Module '{name}' already exists at {target_src_uri}."
        
        final_desc = desc or description or f"YS-Codebase module: {name}"
        
        # 1. Create manifest.json
        uri.write_json(f"{target_src_uri}/manifest.json", {
            "name": name,
            "version": "0.1.0",
            "description": final_desc,
            "entry": "scripts/cli.py",
            "dependencies": {
                "core": ">=1.0.0"
            }
        })
        
        # 2. Create scripts/cli.py
        cli_content = f'''"""
CLI Entry point for module {name}.
"""
from typing import List
import sys
import os

from core.guard import guard_dispatch
from core import uri


def process(args: List[str]) -> int:
    guard_dispatch("{name}")

    # Windows console UTF-8 protection
    if hasattr(sys.stdout, "reconfigure"):
        try:
            sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass

    current_dir = os.path.dirname(os.path.abspath(__file__))
    parent_dir = os.path.dirname(current_dir)
    if parent_dir not in sys.path:
        sys.path.insert(0, parent_dir)

    print(f"[{name}] Executing command with args: " + " ".join(args))
    return 0
'''
        uri.write_text(f"{target_src_uri}/scripts/cli.py", cli_content)
        
        # 3. Create <pkg_name>/__init__.py
        pkg_name = name.replace("-", "_")
        init_content = f'''"""
{name} package initialization.
"""
__version__ = "0.1.0"
'''
        uri.write_text(f"{target_src_uri}/{pkg_name}/__init__.py", init_content)
        
        # 4. Create tests/__init__.py and tests/test_basic.py
        uri.write_text(f"{target_src_uri}/tests/__init__.py", '"""\nTest package.\n"""\n')
        test_content = f'''"""
Basic test for {name}.
"""
import unittest

class TestBasic(unittest.TestCase):
    def test_sample(self):
        self.assertTrue(True)

if __name__ == "__main__":
    unittest.main()
'''
        uri.write_text(f"{target_src_uri}/tests/test_basic.py", test_content)
        
        # 5. Create .yscbignore
        ignore_content = '''# Development ignore list
tests/
*.tmp
*.bak
.pytest_cache/
'''
        uri.write_text(f"{target_src_uri}/.yscbignore", ignore_content)
        
        return True, f"Successfully created module '{name}' at {target_src_uri}."
