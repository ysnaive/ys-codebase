# Phase 3: API 規格與介面契約 (P03 API Spec Guide)

本手冊定義 Phase 3 介面設計階段之型別契約、錯誤處理策略與實作依賴拓撲順序。

---

## 1. 核心定位與職責

- **公開介面簽名契約**：精確定義所有 Public API 的名稱、傳參、回傳型別與 Docstring 介面規範。
- **剛性錯誤處理合約**：顯式定義例外類型與錯誤碼，嚴禁使用模糊的泛型例外或靜默吞噬錯誤。
- **實作依賴拓撲編排**：分析組件依賴關係，排出嚴格的 Bottom-Up 實作先後順序。

---

## 2. `P03_api_spec.md` 產出核心規範

1. **模組/介面簽名清單**：
   - 類別名稱、方法簽名（包含完整 Type Hints）。
   - 參數前置條件 (Pre-conditions) 與回傳後置條件 (Post-conditions)。
2. **錯誤與例外合約**：
   - 標明各 API 可能拋出之自定義例外類別與情境。
3. **實作依賴拓撲順序 (Dependency Topology)**：
   - 依「基礎資料結構 -> 核心底層組件 -> 門面 SDK / CLI 整合」排出相依無環順序（DAG），作為 Phase 5 任務分解之剛性骨幹。
4. **階段決策 ([P03:DR-XX])**：記錄介面命名、型別相容性等決策。

---

`__@{PHASE03_AGENTS_GUILD}__`

---

## [!] 3. Phase 3 結束 Checkpoint

- **極精簡 Session 回覆格式**：產出 `P03_api_spec.md` 並更新 `changelog.md` 後，對話中**嚴禁全文重複、代碼傾倒或冗長轉述**，強制僅呈遞以下極簡卡片：
  ```markdown
  ###  P03 API 規格已落檔
  - **產出文件**：[P03_api_spec.md](__${project://plans/}__/{plan_name}/P03_api_spec.md)
  - **API 摘要**：[新增/變更 API 計 N 組 / 核心決策 [P03:DR-XX] / 實作依賴順序]
  - **待確認事項**：請問是否同意 API 規格定義並推進至 Phase 4（實作計畫定稿）？
  ```
- **立即 End Turn 等待確認**：嚴禁跨階段連續產出。

