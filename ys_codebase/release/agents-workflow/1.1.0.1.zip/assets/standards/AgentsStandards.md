# Agent 專案行為準則與防呆紀律規範 (Agents Standards)

本文件定義 Agent 在專案內執行任務時必須遵守的通用核心原則與條件技能分流導航。

---

## 1. 核心原則 (Core Principles)

1. **零臆測 (Zero Speculation Axiom)**：
   - 不確定細節必須向開發者釐清；嚴禁自行假設需求、猜測 API 或臆測解法。
   - **寬泛指令防呆**：開發者下達抽象或寬泛目標時（例如「優化/打磨」），**嚴禁主動發散腦補具體需求清單**；必須優先反問確認具體目標與期望範圍。
   - **分析授權例外**：唯有開發者明確指示「幫我分析/評估」時，方可基於代碼現況展開客觀架構分析與候選方案對比。
2. **檔案為唯一真理，對話極簡節流 (SSOT & Session Response Throttle)**：
   - **檔案唯一真理來源 (SSOT)**：專案所有規格、代碼、架構、任務與測試成果，以實體檔案（如 `__${project://plans/}__`、`__${project://docs/}__` 等）為唯一真理載體。
   - **對話極簡節流 (Session Response Throttle)**：凡產物已成功落檔或已有實體檔案可查者，對話 Session **嚴禁全文重複、代碼傾倒或冗長轉述**；任何時刻皆應極致精簡對話輸出（僅呈遞必要路徑、核心摘要、關鍵阻塞與下一步），嚴格節約 Token。
3. **終端指令防呆紀律 (CLI Execution Safeguard)**：
   - **指令單行化**：調用終端工具（如 `run_command`）**嚴禁字串夾帶換行 (`\n`)**；多命令以 `&&` 串接，複雜邏輯強制落檔後執行，嚴防 PTY 次級提示字元等待卡死。

---

## 2. 條件式技能分流導航矩陣 (Conditional Skill Trigger Routing)

除「核心原則」為全域強制遵循外，所有開發情境、工作流子步驟與工具調用均依條件分流至專屬 Skill。**執行對應動作或調用原生工具前必須強制觸發並遵循該技能手冊（工作流執行中涉及具體動作時強制複合觸發，嚴禁以工作流替代技能手冊）**：

| 任務情境、業務意圖與原生工具調用攔截 (Trigger Condition & Action Gate) | 強制觸發之技能 (Mandatory Skill) |
| :--- | :--- |
| **開立/推進計畫 / 代碼實作 / plans/ 產物維護**<br/>*(調用檔案編輯寫入工具前；[!] 模板唯一來源為 `__${project://.agents/.yscb/templates/}__`，嚴禁翻讀歷史封存)* | `development-sop` |
| **執行任何 CLI 命令列指令**<br/>*(調用各環境之終端機/命令列執行工具時)* | `yscb-cli-guild` |
| **編寫代碼註解 / 撰寫或維護專案文檔 / Review 階段三層文檔對齊**<br/>*(撰寫 Docstring、維護 docs/、更新 README 或 Review 交付前)* | `documentation` |
`__@{AGENTS_SKILL_ROUTING}__`

> [!NOTE]
> **專案特化技能擴充導引 (Project Contributed Routing)**：  
> 若當前專案需擴充特化條件技能，請於專案組態 `config/agents-workflow/contribute.json` 宣告 `insert` 至 `AGENTS_SKILL_ROUTING` 錨點（宣告式一等公民，升級自動編譯注入，杜絕物化檔案衝突）。
