`__@{BEGIN_HTML_ANNOTATION}__`

現場凍結交接指引：
1. 目標：中斷工作或切換任務時，將現場狀態、未提交進度、踩坑注意事項與下一步動作進行即時上下文凍結 (Context Freeze)。
2. 零斷層接手：確保接手開發者或新 Session Agent 光看 handoff.md 即可在 3 秒內無縫接手，無需猜測探勘。
3. 結構要點：清楚記錄現場已完成事項、未完成待辦、關鍵踩坑注意與重啟第 1 步。

`__@{HANDOFF_AGENTS_GUILD}__`

`__@{END_HTML_ANNOTATION}__`

# 當前進度與暫停交接現場 (Handoff Context)

> 暫停時間：[YYYY-MM-DD HH:MM]  
> 所屬計畫：[計畫名稱]  
> 當前所在階段：[Phase X / FT-Y (狀態: Implementing / In Progress)]  

`__@{HANDOFF_HEADER}__`

> 模板版本：v1.2  

---

## 1. 現場已完成事項
- [x] [已完成的類別/函式/測試項目]
- [x] [已解決的邊界問題]

---

## 2. 現場未完成 / 進行中待辦
- [ ] [具體檔案與函式名：目前做到哪裡、下一步要寫什麼]
- [ ] [尚未編寫或尚未通過之驗證項目]

---

## 3. 踩坑與注意事項 (Gotchas & Blockers)
- [WARN] [關鍵坑點/特殊時序/未解問題/本次討論達成的口頭共識]

---

## 4. 下一次接手時的第 1 步 (Immediate Next Action)
-  [極精確的重啟行動指引，例如「從 xx 函式繼續實作，完成後執行 test 驗證」]

`__@{HANDOFF_TEMPLATE}__`
