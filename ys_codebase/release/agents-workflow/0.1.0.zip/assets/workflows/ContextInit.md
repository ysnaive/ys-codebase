`__@{DYNAMIC_CONTEXT_MAP}__`

# 專案上下文初始化流程 (ContextInit)

本 Workflow 用於在全新對話 (Session / Chat) 開始時，快速加載專案的核心架構、歷史變更、程式碼規範與 Agent 紀律。確保 Agent 即使在大語言模型上下文重置後，也能 100% 掌握專案默契與工程標準。

---

## 🎯 核心原則

1. **沙盒 100% 安全 (Sandbox Native Read)**：優先使用內建檔案讀取工具（如 `view_file`），不依賴需額外權限的 CLI 命令，確保在沙盒模式與完全存取模式下均能無障礙秒級執行。
2. **零臆測脈絡 (Zero Speculation)**：從既有真實文檔（`CHANGELOG.md`、`coding-standards.md`、`AGENTS.md`）載入現況，不自行假設專案結構。
3. **語意 URI 標準化 (Semantic URI Protocol)**：透過 `project://`、`docs://`、`plans://` 等標準協議精準指向各級資源。
4. **極簡 Token 高效加載**：僅抽取專案的核心公理與最新變更，不載入無關細節。

---

## 🚀 執行步驟

當使用者輸入 `/ContextInit` 或 Agent 偵測到是全新的對話 Session 時，Agent **必須順序執行**以下加載步驟：

### 步驟 1：加載專案層級硬性規範與紀律
- **讀取檔案**：[AGENTS.md](`__#{project://AGENTS.md}__`)
- **提取要點**：
  - SOP 三大原則：零臆測、可追溯、分級管控。
  - 嚴禁連發（一次 Turn 最多一個 Phase）、嚴禁空降實作。
  - 除錯排查與範疇保護鐵律、模板註解剝除鐵律。
  - 定式作業指令優先原則、嚴禁主動歸檔。
  - 專案程式碼架構與 `docs/` 知識庫之鏡像同步關係。

### 步驟 2：加載程式碼與命名規範
- **讀取檔案**：[STANDARDS.md](`__#{docs://_project/STANDARDS.md}__`) *(若專案未獨立提供則依 AGENTS.md 為準)*
- **提取要點**：
  - 識別碼與變數命名規範（如前綴、大小寫慣例、命名空間結構）。
  - 單位與型別標註約束（具體變數顯式帶單位，轉換時嚴禁同名覆蓋）。
  - 註解哲學與文檔標準（`docs/` 負責宏觀公理，代碼負責微觀自包含）。

### 步驟 3：加載專案最新演進與當前進度
- **讀取檔案**：[CHANGELOG.md](`__#{project://CHANGELOG.md}__`) (前 2 ~ 3 個區塊)
- **提取要點**：
  - 瞭解專案最近完成了哪些 Dev Plan 與架構優化。
  - 掌握當前專案處於何種演進階段。

### 步驟 4：檢查進行中與歷史 Plan 結構
- **讀取設定**：[config.project.json](`__#{project://config.project.json}__`)
- **提取要點與目錄檢查**：
  - 取得 `plans_dir`（對應 `plans://`）與 `archive_dir`（對應 `archive://`）。
  - 檢查進行中 Plan 與歷史歸檔之目錄結構與進度。

---

## 📋 輸出成果：專案熱啟動簡報 (Context Warmup Summary)

完成上述檔案讀取後，Agent **必須**向開發者呈現以下格式的上下文熱啟動簡報，並結束當前 Turn 等待開發者下達任務：

```markdown
# 🚀 專案上下文已成功熱啟動 (Context Initialized)

已成功載入本專案的核心架構、規範與歷史決策脈絡：

### 📌 專案核心規範摘要 (Coding Standards)
- **目錄與路徑架構**：原始碼與 docs:// 知識庫鏡像對齊。
- **識別碼命名規範**：遵循專案定義之命名風格與前綴慣例。
- **單位與型別約束**：物理/數學變數顯式標註單位，轉換時嚴禁同名覆蓋。
- **註解哲學**：docs:// 宏觀，代碼文檔註解微觀自包含。

### 🛠️ 工具與 SOP 紀律 (Guardrails)
- **SOP 紀律**：嚴禁連發、嚴禁空降實作、除錯排查範疇保護、嚴禁主動歸檔。
- **定式作業**：歷史檢索/歸檔/驗證優先使用 `python yscb_cli.py agents-workflow <verify|scan|search|archive>` 指令。
- **Plan 空間**：進行中計畫位於 `plans://`，歷史歸檔位於 `archive://`。
- **專案進度**：最新已完成 Plan 與核心功能動向已掌控。

---

**🤖 Agent 狀態**：已準備就緒！請問今天我們準備進行什麼任務或功能開發？
```
