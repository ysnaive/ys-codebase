`__@{BEGIN_HTML_ANNOTATION}__`

Umbrella 主計畫執行指引：
1. 目標：統籌跨模組、多情境或大型架構演進任務，以單一主計畫協調多個 sub_XX 子計畫。
2. 主計畫邊界：主計畫本身專注文檔總綱、子計畫拆分與依賴協調，不直接撰寫代碼。
3. 顆粒度與獨立性：每個子計畫以「單個 Full Track 能處理之顆粒度」為拆分單位，獨立推進其 Phase 0~7 或 Fast Track。
4. 最多兩層約束：主計畫 ➔ 子計畫，絕對禁止在子計畫下開設更多層子目錄。
5. 結案與歸檔：子計畫完成後留存主目錄；所有子計畫全數完成後，整個主目錄統一移至 archive://。

`__@{UMBRELLA_AGENTS_GUILD}__`

`__@{END_HTML_ANNOTATION}__`

# 分類型主計畫總覽 (Umbrella Overview)

> 計畫名稱：[計畫名稱]  
> 建立日期：[YYYY-MM-DD]  
> 計畫狀態：[Planning | Executing | Completed]  

`__@{UMBRELLA_HEADER}__`

> 模板版本：v1.1  

---

## 1. 主計畫願景與目標 (Vision & Goals)

- **核心願景**：
- **架構邊界**：

---

## 2. 子計畫拆分與執行矩陣 (Sub-Plan Breakdown)

| 子計畫編號 | 子計畫目錄名稱 | 分流層級 | 當前狀態 | 核心範疇說明 |
| :---: | :--- | :---: | :---: | :--- |
| **sub_01** | `sub_01_xxx` | Full Track | `Pending` | |

---

## 3. 主計畫里程碑與推進狀態 (Milestones)

- [ ] **里程碑 1**：

`__@{UMBRELLA_TEMPLATE}__`
