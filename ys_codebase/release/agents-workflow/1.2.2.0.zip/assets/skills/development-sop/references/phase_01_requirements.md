# Phase 1: 規格轉譯 (P01 Requirements Spec Guide)

本手冊定義 Phase 1 規格轉譯階段之需求分類、剛性標籤定義與品質守門規範。

```markdown
Phase 01 執行檢核表：
- [ ] 1. 讀取已 Confirmed 之 P00_discuss.md 與 P01_requirements_spec.md 模板
- [ ] 2. 逐項編列 FR-XX、EC-XX、NFR-XX 並記錄階段決策 [P01:DR-XX]
- [ ] 3. 檢查是否有未定義清楚的邊界（若有歧義立即暫停提問，禁止臆測或範疇蔓延）
- [ ] 4. 寫入 P01_requirements_spec.md、更新 changelog.md，輸出狀態卡並立即 End Turn
```

---

## 1. 核心定位與職責

- **1:1 剛性轉譯**：將 `P00_discuss.md` 達成的需求共識轉譯為結構化規格。
- **嚴禁超載 (No Scope Creep)**：絕對禁止夾帶或私自發散未在 P00 中討論確認之功能。

---

## 2. 三大需求分類與標籤定義

| 分類類別 | 標籤格式 | 核心要求與規範 |
| :--- | :--- | :--- |
| **功能需求 (FR)** | `FR-{XX}` | 每個 FR 必須具備明確且客觀之驗收條件 (Acceptance Criteria)。 |
| **邊界條件 (EC)** | `EC-{XX}` | 全面覆蓋空值、極值、不存在路徑、超時、例外輸入與並發衝突防禦。 |
| **非功能需求 (NFR)** | `NFR-{XX}` | 具體量化效能指標（如回應時間 $\le 100\text{ms}$）、記憶體上限或平臺相容性。 |

---

## 3. `P01_requirements_spec.md` 產出核心規範

- **需求規格矩陣**：條列 `FR-01`、`EC-01`、`NFR-01` 等結構化條目。
- **剛性追溯起點**：每個 FR/EC 均為後續架構 (P02)、API (P03)、實作 (P05) 與測試 (P06) 的剛性溯源錨點。
- **驗收條件**：於 §1 表格「詳細規格與驗收條件 (Acceptance Criteria)」欄內，為每個 FR 寫明客觀可驗證之驗收條件。
- **階段決策 ([P01:DR-XX])**：記錄規格定義過程中確定的邊界取捨決策，登載於對應 FR/EC 條目內或計畫 `changelog.md`。

`__@{PHASE01_AGENTS_GUIDE}__`

---

## [!] 4. Phase 1 結束 Checkpoint

- **極精簡 Session 回覆格式**：產出 `P01_requirements_spec.md` 並更新 `changelog.md` 後，對話中**嚴禁全文重複或冗長轉述**，強制僅呈遞以下極簡卡片：
  ```markdown
  ###  P01 規格轉譯已落檔
  - **產出文件**：[P01_requirements_spec.md](`__${project://plans}__/{plan_name}/P01_requirements_spec.md`)
  - **規格摘要**：[FR 清單計 N 項, EC 清單計 N 項 / 核心決策 [P01:DR-XX]]
  - **待確認事項**：請問是否同意規格定義並推進至 Phase 2（架構設計）？
  ```
- **立即 End Turn 等待確認**：嚴禁跨階段連續產出。

