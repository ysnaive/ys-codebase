# Phase 5: 任務實作與編碼紀律 (P05 Task Guide)

本手冊定義 Phase 5 編碼實作階段之任務編排、空間隔離鐵律、代碼註解規範與實作偏差處置標準。

```markdown
Phase 05 執行檢核表：
- [ ] 1. 讀取 P05_task.md 模板，依 P04 建立 [TASK-XX] 實作任務清單
- [ ] 2. 依序完成源碼實作、補齊 Docstring 與單元測試，每完成一項即勾選 P05_task.md 對應任務
- [ ] 3. 如實記錄任何 Minor 偏差（若遇 Major/Critical 偏差立即依矩陣暫停或轉 /discuss）
- [ ] 4. 將 P05_task.md 狀態更新為 Completed、更新 changelog.md，呈遞狀態卡並立即 End Turn
```

---

## 1. 核心定位與職責

- **依序實作**：依據 `P04` 依賴拓撲建立 `P05_task.md`，並逐一實作代碼與測試。
- **文檔同步交付**：將中觀手冊與微觀註解列為一等公民任務同步交付，嚴禁後補。
- **偏差即時留痕**：任何與原計畫不符的改動必須嚴格分級處置。

---

## 2. 空間隔離與代碼規範鐵律

1. **源碼空間唯一 SSOT**：
   - 所有代碼修改 **100% 必須在專案源碼空間進行**，嚴禁手動直接修改部署運行端、第三方依賴目錄或編譯中介產物。
2. **公開介面註解保護 (Docstring Preservation)**：
   - 重構或新增 Public API 時，**嚴禁刪減或破壞標準介面註解結構**（說明、傳參、回傳與例外規範）。
3. **意圖導向行內註解 (Why-Driven Comments)**：
   - 凡涉及非直觀演算法、邊界補償或特定常數，行內註解必須記錄「為什麼這樣做 (Why)」，嚴禁僅複述語法操作 (What)。
4. **動作前置技能調用與測試／代碼品質連鎖觸發**：
   - 編輯源碼、執行測試或維護文檔前，須依專案規範調用對應之專屬技能，不可省略。
   - **[!] 業務程式碼結構衛生與無損重構鐵律**：編寫或修改業務生產源碼時，**強制遵循 [`CodeQualityStandards.md`](`__#{module://agents-workflow/assets/standards/CodeQualityStandards.md}__`)** 之四大防過度設計紅線、五維度品質指標（`D1~D5`）與 `S1~S6` 結構法則（落實公開方法主幹階段管線化 `S1`、無狀態純函式剝離與**零轉發殼層** `S2`、同構邏輯 20% 邊界不變量保護 `S3`、衛語句扁平化 `S4`，且**嚴禁在生產代碼註解或 Docstring 留存 `FR-XX` / `DR-XX` / `EC-XX` 等開發計畫工單標籤**）。
   - **撰寫或修改自動化測試腳本前，強制先觸發並遵循 [`testing-sop`](`__#{module://agents-workflow/assets/skills/testing-sop/SKILL.md}__`)**，嚴格落實實質副作用斷言與 `tearDown` / `try...finally` 沙盒零殘留清理。

---

## [WARN] 3. 實作偏差三級處置矩陣 (Deviation Matrix)

| 偏差等級 | 判定條件 | 處置行動 |
| :--- | :--- | :--- |
| [!] **Critical** | 需求越界、架構翻盤、破壞全域相容性 | **強制中斷實作**，發起 [/discuss](`__#{module://agents-workflow/assets/skills/discuss/SKILL.md}__`) 進行 5-Whys 根因分析，退回 P00/P01 重新定稿。 |
| [WARN] **Major** | 局部 API 簽名微調、新增模組內部依賴 | **暫停推進**，於當前 Turn 呈報開發者確認同意後再行修改。 |
| ℹ️ **Minor** | 內部區域變數重命名、演算法非介面層微調 | 自主修正，並於 `P05_task.md` 之「實作偏差紀錄表」登記備查。 |

`__@{PHASE05_AGENTS_GUIDE}__`

---

## [!] 4. Phase 5 結束 Checkpoint

- 所有 `TASK-XX` 與 `TASK-DOC` 均標記為完成 `[x]` 並通過專案語法與靜態合規檢查。
- **極精簡 Session 回覆格式**：產出 `P05_task.md` 並更新 `changelog.md` 後，對話中**嚴禁全文重複、代碼傾倒或冗長轉述**，強制僅呈遞以下極簡卡片：
  ```markdown
  ###  P05 任務實作已完成
  - **產出文件**：[P05_task.md](`__${project://plans}__/{plan_name}/P05_task.md`)
  - **實作摘要**：[完成 TASK 計 N 項、文檔同步 N 項 / 靜態檢查通過 / 偏差處置說明]
  - **待確認事項**：實作已完成，請問是否推進至 Phase 6（測試驗證）？
  ```
- **立即 End Turn 等待確認**：嚴禁跨階段連續產出。

