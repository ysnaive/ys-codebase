"""
knowledge-db scripts package
"""
