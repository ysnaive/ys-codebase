"""
knowledge-db scripts package
"""
