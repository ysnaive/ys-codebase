"""
CLI router entry point for module:knowledge-db.
Migrated to core.commands active execution contract with strong-typed CmdBags.
"""

import json
import os
import sys
from typing import Any, Dict, List, Optional, Union

from core.commands import CmdBags, CmdOption
from core.guard import guard_dispatch
import knowledge_db.config as kdb_config
from knowledge_db.engine import KnowledgeEngine, get_engine
from knowledge_db.exceptions import KnowledgeDBError, SpaceNotFoundError
from knowledge_db.formatter import TerminalStyler


def _normalize_bags(cmd_bags: Any, default_cmd: str = "") -> CmdBags:
    """容錯正規化：若傳入 List[str] 則包裝為 CmdBags，支援內部測試直呼。"""
    if isinstance(cmd_bags, CmdBags):
        return cmd_bags
    if isinstance(cmd_bags, (list, tuple)):
        args = list(cmd_bags)
        raw_cmd = " ".join(args)
        opts = {}
        pos = []
        for a in args:
            if a.startswith("--"):
                k = a[2:]
                v = True
                if "=" in k:
                    k, val = k.split("=", 1)
                    v = val
                opts[k] = CmdOption(name=k, params=v)
            elif a.startswith("-") and len(a) > 1:
                k = a[1:]
                opts[k] = CmdOption(name=k, params=True)
            else:
                pos.append(a)
        return CmdBags(raw_cmd=raw_cmd, command=default_cmd, args=pos, options=opts)
    return CmdBags(raw_cmd="", command=default_cmd, args=[], options={})


def _setup_stream_encodings():
    if hasattr(sys.stdout, "reconfigure"):
        try:
            sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
    if hasattr(sys.stderr, "reconfigure"):
        try:
            sys.stderr.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass


def status(cmd_bags: Any) -> int:
    """查看知識庫空間狀態、指紋快取、同義詞與索引統計。"""
    guard_dispatch("knowledge-db")
    _setup_stream_encodings()
    bags = _normalize_bags(cmd_bags, "status")
    engine = get_engine()

    try:
        scan_mode = bags.has_option("scan") or bags.has_option("diff")
        targets = bags.args
        space_target = bags.get_option_value("space") or (targets[0] if targets and not (bags.has_option("all") or bags.has_option("a")) else None)

        st = engine.status(space=space_target, scan=scan_mode)
        if bags.has_option("json"):
            json_st = dict(st)
            if "scan_diff" in json_st and json_st["scan_diff"]:
                json_st["scan_diff"] = {
                    k: {
                        "added": list(v.added),
                        "modified": list(v.modified),
                        "deleted": list(v.deleted),
                        "unchanged": list(v.unchanged),
                    }
                    for k, v in json_st["scan_diff"].items()
                }
            print(json.dumps(json_st, indent=2, ensure_ascii=False))
            return 0
        styler = TerminalStyler(sys.stdout)
        print(f"[knowledge-db] 系統狀態摘要 (共 {st['total_spaces']} 個空間):")
        print(f"  - 存儲空間根目錄: {styler.path(st['storage_dir'])}")
        unified_str = styler.symbol("已建立") if st.get("has_unified_index") else styler.warn("未建立")
        print(f"  - 全域倒排索引: {unified_str}")
        if not st.get("enable_vector_search"):
            vec_str = styler.line("已停用 (依組態停用向量檢索)")
        elif st.get("has_vector_index"):
            vec_str = styler.symbol(f"已建立 (模型: {st.get('embedding_model')})")
        else:
            vec_str = styler.warn("未建立")
        print(f"  - 向量特徵索引: {vec_str}")
        model_str = styler.symbol("已下載") if st.get("model_downloaded") else styler.warn("未下載 (離線時自動降級 BM25)")
        print(f"  - 向量模型權重: {model_str}")
        load_errs = st.get("parser_load_errors") or {}
        if load_errs:
            print(f"  - 解析器狀態  : {styler.warn(f'警告 ({len(load_errs)} 個語言載入失敗)')}")
            for lid, err_txt in load_errs.items():
                print(f"    [WARN] 語言 '{lid}': {err_txt}", file=sys.stderr)
        print("-" * 80)
        for name, sp in st["spaces"].items():
            pat_str = f" [patterns: {', '.join(sp['file_patterns'])}]" if sp.get('file_patterns') else " [all files]"
            is_idx = sp.get('has_index') or st.get("has_unified_index")
            idx_str = styler.symbol("已建立") if is_idx else styler.warn("未建立")
            print(f"  - 空間: {styler.path(name)} (來源: {sp.get('origin', 'unknown')}){pat_str}")
            if sp.get("description"):
                print(f"    說明: {sp['description']}")
            print(f"    來源目錄數: {sp.get('include_count', 0)}, 快取檔案: {sp.get('cached_files', 0)} 檔, 倒排索引: {idx_str}")
        print("-" * 80)

        if scan_mode and st.get("scan_diff"):
            diffs = st["scan_diff"]
            print("[knowledge-db] 增量指紋比對結果:")
            for sp_name, diff in diffs.items():
                print(
                    f"  - 空間 '{sp_name}': Added={len(diff.added)}, Modified={len(diff.modified)}, "
                    f"Deleted={len(diff.deleted)}, Unchanged={len(diff.unchanged)}"
                )
            print("-" * 80)

        return 0
    except SpaceNotFoundError as e:
        print(f"[knowledge-db] 空間不存在: {e}", file=sys.stderr)
        return 1
    except KnowledgeDBError as e:
        print(f"[knowledge-db] 操作失敗: {e}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"[knowledge-db] 執行異常: {e}", file=sys.stderr)
        return 1


def index(cmd_bags: Any) -> int:
    """建置與快取指定空間或全空間聯集之多欄位倒排索引。"""
    guard_dispatch("knowledge-db")
    _setup_stream_encodings()
    bags = _normalize_bags(cmd_bags, "index")
    engine = get_engine()

    try:
        force = bags.has_option("force") or bags.has_option("f")
        targets = bags.args
        space_target = targets[0] if targets and not (bags.has_option("all") or bags.has_option("a")) else None
        export_arg = bags.get_option_value("export")

        indices = engine.build_index(space=space_target, force=force, interactive=True, export_path=export_arg)
        load_errs = getattr(engine.parser_registry, "load_errors", None) or {}
        if load_errs:
            print(
                f"[knowledge-db] [WARN] 偵測到 {len(load_errs)} 個自訂或擴充語言解析器載入失敗（對應檔案將略過符號解析）：",
                file=sys.stderr,
            )
            for lid, err_txt in load_errs.items():
                print(f"  - [{lid}] {err_txt}", file=sys.stderr)
        print(f"[knowledge-db] 倒排索引建置完成 (共 {len(indices)} 個空間):")
        for sp_name, idx in indices.items():
            print(f"  - 空間 '{sp_name}': {idx.doc_count} 篇文檔符號，{len(idx.index)} 個 Term 索引詞")
        if export_arg:
            print(f"  - 語意 Bundle 已導出至: {export_arg}")
        return 0
    except SpaceNotFoundError as e:
        print(f"[knowledge-db] 空間不存在: {e}", file=sys.stderr)
        return 1
    except KnowledgeDBError as e:
        print(f"[knowledge-db] 操作失敗: {e}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"[knowledge-db] 執行異常: {e}", file=sys.stderr)
        return 1


def model(cmd_bags: Any) -> int:
    """向量模型管理群組分發器。"""
    guard_dispatch("knowledge-db")
    _setup_stream_encodings()
    bags = _normalize_bags(cmd_bags, "model")
    sub_cmd = bags.args[0] if bags.args else "status"
    if sub_cmd == "status":
        sub_bags = CmdBags(raw_cmd=bags.raw_cmd, command="status", args=bags.args[1:], options=bags.options)
        return model_status(sub_bags)
    elif sub_cmd in ("download", "pull"):
        sub_bags = CmdBags(raw_cmd=bags.raw_cmd, command="download", args=bags.args[1:], options=bags.options)
        return model_download(sub_bags)
    else:
        print(f"[knowledge-db] 未知 model 子指令: '{sub_cmd}'。可用子指令: status, download", file=sys.stderr)
        return 1


def model_status(cmd_bags: Any) -> int:
    """檢視本地向量模型權重快取目錄、檔案狀態與維度。"""
    guard_dispatch("knowledge-db")
    _setup_stream_encodings()
    bags = _normalize_bags(cmd_bags, "model status")
    engine = get_engine()
    try:
        st = engine.model_status()
        if bags.has_option("json"):
            print(json.dumps(st, indent=2, ensure_ascii=False))
            return 0

        styler = TerminalStyler(sys.stdout)
        print("[knowledge-db] 向量推論模型狀態:")
        print(f"  - 模型名稱: {styler.bold(st['model_name'])}")
        print(f"  - 快取目錄: {styler.path(st['cache_dir'])}")
        dl_str = styler.symbol("已就緒") if st.get("is_downloaded") else styler.warn("未下載")
        print(f"  - 本地權重: {dl_str}")
        av_str = styler.symbol("可用") if st.get("is_available") else styler.warn("不可用 (將降級至 BM25)")
        print(f"  - 服務狀態: {av_str}")
        print(f"  - 向量維度: {st['dimension']}")
        return 0
    except KnowledgeDBError as e:
        print(f"[knowledge-db] 操作失敗: {e}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"[knowledge-db] 執行異常: {e}", file=sys.stderr)
        return 1


def model_download(cmd_bags: Any) -> int:
    """顯式下載 FastEmbed 向量模型權重至本地快取。"""
    guard_dispatch("knowledge-db")
    _setup_stream_encodings()
    bags = _normalize_bags(cmd_bags, "model download")
    engine = get_engine()
    try:
        force = bags.has_option("force") or bags.has_option("f")
        print(f"[knowledge-db] 開始準備下載/載入向量模型 '{engine.embedding_service.model_name}' (force={force})...")
        success = engine.model_download(force=force)
        if success:
            st = engine.model_status()
            print(f"[knowledge-db] 向量模型下載成功，已就緒可用 (維度: {st['dimension']})。")
            return 0
        else:
            print("[knowledge-db] 向量模型下載未完成。", file=sys.stderr)
            return 1
    except KnowledgeDBError as e:
        print(f"[knowledge-db] 下載失敗: {e}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"[knowledge-db] 執行異常: {e}", file=sys.stderr)
        return 1


def search(cmd_bags: Any) -> int:
    """對全空間或指定空間符號進行多欄位加權 BM25 語意檢索。"""
    guard_dispatch("knowledge-db")
    _setup_stream_encodings()
    bags = _normalize_bags(cmd_bags, "search")
    engine = get_engine()

    try:
        queries = bags.args
        if not queries:
            print("[knowledge-db] 錯誤: 請輸入檢索查詢詞。例如: python yscb.py knowledge-db search 'InvertedIndex' -s", file=sys.stderr)
            return 1

        query_str = " ".join(queries)
        space_filter = bags.get_option_value("space")
        kind_filter = [bags.get_option_value("kind")] if bags.get_option_value("kind") else None
        lang_filter = [bags.get_option_value("lang")] if bags.get_option_value("lang") else None
        ftype_filter = bags.get_option_value("ftype")
        lexical_only = bags.has_option("lexical-only")

        opts = _parse_common_display_options(bags)
        tier = opts["tier"]
        limit_val = opts["limit_val"]
        is_json = opts["is_json"]
        is_md = opts["is_md"]
        is_snippet = opts["is_snippet"]
        detail_mode = "detail" if tier == "detail" else ("auto" if tier == "snippet" else "simple")
        if limit_val == "auto":
            fetch_limit = 10 if (is_json and tier == "snippet") else 50
        else:
            fetch_limit = max(1, int(limit_val))

        max_snippet_lines = 40
        msl_opt = bags.get_option_value("max-snippet-lines")
        if msl_opt:
            try:
                max_snippet_lines = max(5, int(str(msl_opt).strip()))
            except ValueError:
                max_snippet_lines = 40

        def _cap_json_snippet(cs: Any) -> Dict[str, Any]:
            if not cs or not getattr(cs, "lines", None):
                return {}
            raw_lines = cs.lines
            if tier == "snippet" and len(raw_lines) > max_snippet_lines:
                kept = raw_lines[:max_snippet_lines]
                s_ln = kept[0][0]
                e_ln = kept[-1][0]
                full_end = getattr(cs, "end_line", raw_lines[-1][0])
                omitted_count = len(raw_lines) - max_snippet_lines
                if kdb_config.is_agents_workflow_installed():
                    try:
                        from core import locale as core_locale
                        trunc_suffix = core_locale.t(
                            "cli.search.snippet_truncated_hint",
                            module="knowledge-db",
                            omitted=omitted_count,
                            start_line=cs.start_line,
                            end_line=full_end,
                        )
                    except Exception:
                        trunc_suffix = (
                            f"\n... [truncated {omitted_count} lines; "
                            f"target spans lines {cs.start_line}-{full_end}, use native file reader with line range to view]"
                        )
                else:
                    trunc_suffix = (
                        f"\n... [truncated {omitted_count} lines; "
                        f"target spans lines {cs.start_line}-{full_end}]"
                    )
                code_str = "\n".join(txt for _, txt in kept) + trunc_suffix
                return {
                    "code": code_str,
                    "code_lines": [s_ln, e_ln],
                    "full_code_lines": [cs.start_line, full_end],
                    "truncated": True,
                }
            return {
                "code": cs.get_raw_code(),
                "code_lines": [cs.start_line, cs.end_line],
            }

        from knowledge_db.selector import SymbolSelector
        parsed_sel = SymbolSelector.parse(query_str)
        search_query = query_str
        if parsed_sel.target_kinds and not kind_filter:
            kind_filter = list(parsed_sel.target_kinds)
            search_query = f"{parsed_sel.scope}.{parsed_sel.identifier}" if parsed_sel.scope else parsed_sel.identifier
        elif parsed_sel.is_callable and not kind_filter:
            kind_filter = ["function", "method"]
            search_query = f"{parsed_sel.scope}.{parsed_sel.identifier}" if parsed_sel.scope else parsed_sel.identifier

        results = engine.search(
            query=search_query,
            space=space_filter,
            kinds=kind_filter,
            languages=lang_filter,
            ftypes=ftype_filter,
            limit=fetch_limit,
            snippet=is_snippet,
            lexical_only=lexical_only,
        )

        if is_json:
            filtered_results = [res for res in results if res.items]
            if tier == "detail":
                data = [
                    {
                        "file_path": engine.normalize_workspace_path(res.file_path),
                        "file_uri": engine.to_file_uri(res.file_path, line=res.items[0].symbol.line_number if res.items else None),
                        "total_score": round(res.total_score, 2),
                        "language": res.language,
                        "spaces": getattr(res, "spaces", []),
                        "items": [
                            {
                                "id": itm.symbol.id,
                                "name": itm.symbol.name,
                                "kind": itm.symbol.kind,
                                "line_number": itm.symbol.line_number,
                                "end_line": itm.symbol.end_line,
                                "score": round(itm.score, 2),
                                "matched_terms": getattr(itm, "matched_terms", []),
                                "signature": itm.symbol.signature,
                                "summary": itm.snippet or (itm.code_snippet.docstring_summary if itm.code_snippet else ""),
                                **({"code": itm.code_snippet.get_raw_code(), "code_lines": [itm.code_snippet.start_line, itm.code_snippet.end_line]} if (itm.code_snippet and itm.code_snippet.lines) else {}),
                            }
                            for itm in res.items
                        ],
                    }
                    for res in filtered_results
                ]
                print(json.dumps({"query": query_str, "tier": "detail", "total": len(data), "results": data}, indent=2, ensure_ascii=False))
            elif tier == "snippet":
                data = [
                    {
                        "file_path": engine.normalize_workspace_path(res.file_path),
                        "file_uri": engine.to_file_uri(res.file_path, line=res.items[0].symbol.line_number if res.items else None),
                        "total_score": round(res.total_score, 2),
                        "language": res.language,
                        "items": [
                            {
                                "name": itm.symbol.name,
                                "kind": itm.symbol.kind,
                                "line_number": itm.symbol.line_number,
                                "end_line": itm.symbol.end_line,
                                "score": round(itm.score, 2),
                                "signature": itm.symbol.signature,
                                "summary": itm.snippet or (itm.code_snippet.docstring_summary if itm.code_snippet else ""),
                                **_cap_json_snippet(itm.code_snippet),
                            }
                            for itm in res.items
                        ],
                    }
                    for res in filtered_results
                ]
                print(json.dumps({"query": query_str, "tier": "preview", "total": len(data), "results": data}, separators=(',', ':'), ensure_ascii=False))
            else:
                data = [
                    {
                        "file_path": engine.normalize_workspace_path(res.file_path),
                        "file_uri": engine.to_file_uri(res.file_path, line=res.items[0].symbol.line_number if res.items else None),
                        "total_score": round(res.total_score, 2),
                        "language": res.language,
                        "items": [
                            {
                                "name": itm.symbol.name,
                                "kind": itm.symbol.kind,
                                "line_number": itm.symbol.line_number,
                                "end_line": itm.symbol.end_line,
                                "score": round(itm.score, 2),
                                "signature": itm.symbol.signature,
                            }
                            for itm in res.items
                        ],
                    }
                    for res in filtered_results
                ]
                print(json.dumps({"query": query_str, "tier": "simple", "total": len(data), "results": data}, separators=(',', ':'), ensure_ascii=False))
            return 0

        fmt_type = "md" if is_md else "text"
        formatted_output = engine.format_search_output(
            results=results,
            query=query_str,
            detail_mode=detail_mode,
            snippet=is_snippet,
            format_type=fmt_type,
            limit_mode=limit_val,
        )
        print(formatted_output)
        return 0
    except SpaceNotFoundError as e:
        print(f"[knowledge-db] 空間不存在: {e}", file=sys.stderr)
        return 1
    except KnowledgeDBError as e:
        print(f"[knowledge-db] 操作失敗: {e}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"[knowledge-db] 執行異常: {e}", file=sys.stderr)
        return 1


def _parse_common_display_options(bags: CmdBags) -> Dict[str, Any]:
    """解析查詢命令共用之 tier / limit / json / md 顯示選項。"""
    tier = "simple"
    if bags.has_option("detail") or bags.has_option("d") or bags.has_option("verbose"):
        tier = "detail"
    elif bags.has_option("snippet") or bags.has_option("s") or bags.has_option("preview"):
        tier = "snippet"
    elif bags.has_option("simple"):
        tier = "simple"

    is_json = bags.has_option("json")
    is_md = bags.has_option("md") or bags.has_option("markdown")
    limit_val: Union[int, str] = "auto"
    l_opt = bags.get_option_value("limit")
    if l_opt:
        l_val = str(l_opt).strip()
        if l_val.lower() == "auto":
            limit_val = "auto"
        else:
            try:
                limit_val = int(l_val)
            except ValueError:
                limit_val = "auto"

    is_snippet = (tier in ("snippet", "detail")) or bags.has_option("s") or bags.has_option("snippet") or bags.has_option("preview")
    return {
        "tier": tier,
        "is_json": is_json,
        "is_md": is_md,
        "limit_val": limit_val,
        "is_snippet": is_snippet,
        "detail_mode": "detail" if tier == "detail" else "simple",
        "fmt_type": "md" if is_md else "text",
    }


def _serialize_target_symbol(engine: KnowledgeEngine, tsym: Any, tier: str) -> Optional[Dict[str, Any]]:
    if not tsym:
        return None
    if tier == "detail":
        return {
            "id": tsym.id,
            "name": tsym.name,
            "kind": tsym.kind,
            "file_path": engine.normalize_workspace_path(tsym.file_path),
            "file_uri": engine.to_file_uri(tsym.file_path, line=tsym.line_number),
            "line_number": tsym.line_number,
            "end_line": tsym.end_line,
            "signature": tsym.signature,
        }
    if tier == "snippet":
        return {
            "name": tsym.name,
            "kind": tsym.kind,
            "file_path": engine.normalize_workspace_path(tsym.file_path),
            "file_uri": engine.to_file_uri(tsym.file_path, line=tsym.line_number),
            "line_number": tsym.line_number,
            "end_line": tsym.end_line,
            "signature": tsym.signature,
        }
    return {
        "name": tsym.name,
        "kind": tsym.kind,
        "file_path": engine.normalize_workspace_path(tsym.file_path),
        "line_number": tsym.line_number,
    }


def _run_topology_cli_command(cmd_name: str, cmd_bags: Any, example_usage: str) -> int:
    """執行 callers / callees / impact 共用參數解析、Engine 呼叫、JSON/Markdown/Text 渲染與例外守門。"""
    guard_dispatch("knowledge-db")
    _setup_stream_encodings()
    bags = _normalize_bags(cmd_bags, cmd_name)
    engine = get_engine()

    try:
        targets = bags.args
        if not targets:
            print(f"[knowledge-db] 錯誤: 請指定目標符號名稱。例如: {example_usage}", file=sys.stderr)
            return 1
        query_str = targets[0]
        space_target = bags.get_option_value("space")
        ftype_filter = bags.get_option_value("ftype")
        opts = _parse_common_display_options(bags)
        tier = opts["tier"]
        limit_val = opts["limit_val"]
        is_snippet = opts["is_snippet"]

        if cmd_name == "impact":
            depth = 2
            d_opt = bags.get_option_value("depth")
            if d_opt:
                try:
                    depth = int(str(d_opt).strip())
                except ValueError:
                    depth = 2
            res = engine.impact(target_query=query_str, depth=depth, space=space_target, ftypes=ftype_filter)
            if opts["is_json"]:
                tsym = res.get("target_symbol")
                if tier == "detail":
                    print(json.dumps({
                        "target_query": res.get("target_query"),
                        "tier": "detail",
                        "target_symbol": _serialize_target_symbol(engine, tsym, "detail"),
                        "max_depth": res.get("max_depth", depth),
                        "total_impacted_symbols": res.get("total_impacted_symbols", 0),
                        "total_impacted_files": res.get("total_impacted_files", 0),
                        "layers": {
                            str(d): [
                                _serialize_target_symbol(engine, s, "detail")
                                for s in syms
                            ]
                            for d, syms in res.get("layers", {}).items()
                        },
                        "call_chains": res.get("call_chains", {}),
                    }, indent=2, ensure_ascii=False))
                else:
                    print(json.dumps({
                        "target_query": res.get("target_query"),
                        "tier": "simple",
                        "target_symbol": _serialize_target_symbol(engine, tsym, "simple"),
                        "max_depth": res.get("max_depth", depth),
                        "total_impacted_symbols": res.get("total_impacted_symbols", 0),
                        "total_impacted_files": res.get("total_impacted_files", 0),
                        "layers": {
                            str(d): [
                                _serialize_target_symbol(engine, s, "simple")
                                for s in syms
                            ]
                            for d, syms in res.get("layers", {}).items()
                        },
                    }, separators=(',', ':'), ensure_ascii=False))
                return 0
            print(engine.format_impact_output(
                result=res,
                detail_mode=opts["detail_mode"],
                format_type=opts["fmt_type"],
                limit_mode=limit_val,
            ))
            return 0

        is_callers = (cmd_name == "callers")
        if is_callers:
            res = engine.callers(target_query=query_str, space=space_target, snippet=is_snippet, ftypes=ftype_filter)
        else:
            res = engine.callees(target_query=query_str, space=space_target, snippet=is_snippet, ftypes=ftype_filter)

        if opts["is_json"]:
            tsym = res.get("target_symbol")
            list_key = "callers" if is_callers else "callees"
            total_key = "total_callers" if is_callers else "total_callees"
            sym_key = "caller_symbol" if is_callers else "symbol"
            raw_items = res.get(list_key, [])
            filtered_items = raw_items[:limit_val] if (isinstance(limit_val, int) and limit_val > 0) else raw_items

            if tier == "detail":
                print(json.dumps({
                    "target_query": res.get("target_query"),
                    "tier": "detail",
                    "target_symbol": _serialize_target_symbol(engine, tsym, "detail"),
                    total_key: len(filtered_items),
                    list_key: [
                        {
                            sym_key: _serialize_target_symbol(engine, c["symbol"], "detail"),
                            "call_sites": [
                                {
                                    "line_number": s.get("line_number"),
                                    "scope": s.get("scope"),
                                    "file_uri": engine.to_file_uri(
                                        c["symbol"].file_path if is_callers else (tsym.file_path if tsym else c["symbol"].file_path),
                                        line=s.get("line_number"),
                                    ),
                                }
                                for s in c.get("call_sites", [])
                            ],
                            **({"code_snippet": c["code_snippet"].to_dict()} if (is_snippet and c.get("code_snippet")) else {}),
                        }
                        for c in filtered_items
                    ],
                }, indent=2, ensure_ascii=False))
            elif tier == "snippet":
                print(json.dumps({
                    "target_query": res.get("target_query"),
                    "tier": "preview",
                    "target_symbol": _serialize_target_symbol(engine, tsym, "snippet"),
                    total_key: len(filtered_items),
                    list_key: [
                        {
                            sym_key: {
                                "name": c["symbol"].name,
                                "kind": c["symbol"].kind,
                                "file_path": engine.normalize_workspace_path(c["symbol"].file_path),
                                "line_number": c["symbol"].line_number,
                                "end_line": c["symbol"].end_line,
                            },
                            "call_sites": [s.get("line_number") for s in c.get("call_sites", []) if s.get("line_number")],
                            **({"code": c["code_snippet"].get_raw_code(), "code_lines": [c["code_snippet"].start_line, c["code_snippet"].end_line]} if (c.get("code_snippet") and c["code_snippet"].lines) else {}),
                        }
                        for c in filtered_items
                    ],
                }, separators=(',', ':'), ensure_ascii=False))
            else:
                print(json.dumps({
                    "target_query": res.get("target_query"),
                    "tier": "simple",
                    "target_symbol": _serialize_target_symbol(engine, tsym, "simple"),
                    total_key: len(filtered_items),
                    list_key: [
                        {
                            sym_key: _serialize_target_symbol(engine, c["symbol"], "simple"),
                            "call_sites": [s.get("line_number") for s in c.get("call_sites", []) if s.get("line_number")],
                        }
                        for c in filtered_items
                    ],
                }, separators=(',', ':'), ensure_ascii=False))
            return 0

        formatter_fn = engine.format_callers_output if is_callers else engine.format_callees_output
        print(formatter_fn(
            result=res,
            detail_mode=opts["detail_mode"],
            snippet=is_snippet,
            format_type=opts["fmt_type"],
            limit_mode=limit_val,
        ))
        return 0
    except SpaceNotFoundError as e:
        print(f"[knowledge-db] 空間不存在: {e}", file=sys.stderr)
        return 1
    except KnowledgeDBError as e:
        print(f"[knowledge-db] 操作失敗: {e}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"[knowledge-db] 執行異常: {e}", file=sys.stderr)
        return 1


def callers(cmd_bags: Any) -> int:
    """查詢調用指定函式/類別之所有上游調用者 (Callers) 與代碼切片。"""
    return _run_topology_cli_command(
        "callers",
        cmd_bags,
        "python yscb.py knowledge-db callers 'InvertedIndex.load_binary'",
    )


def callees(cmd_bags: Any) -> int:
    """查詢指定函式/類別內部調用了哪些下游方法 (Callees) 與依賴。"""
    return _run_topology_cli_command(
        "callees",
        cmd_bags,
        "python yscb.py knowledge-db callees 'InvertedIndex.patch_incremental'",
    )


def impact(cmd_bags: Any) -> int:
    """評估符號變更或重構時向上擴散之多階調用影響面 (Blast Radius)。"""
    return _run_topology_cli_command(
        "impact",
        cmd_bags,
        "python yscb.py knowledge-db impact 'InvertedIndex.patch_incremental' --depth=2",
    )


def clean(cmd_bags: Any) -> int:
    """清理指定空間或全空間之指紋、Bundle 與倒排索引快取。"""
    guard_dispatch("knowledge-db")
    _setup_stream_encodings()
    bags = _normalize_bags(cmd_bags, "clean")
    engine = get_engine()

    try:
        targets = bags.args
        space_target = targets[0] if targets and not (bags.has_option("all") or bags.has_option("a")) else None

        engine.clean(space=space_target)
        target_str = f"空間 '{space_target}'" if space_target else "全空間"
        print(f"[knowledge-db] 成功清理 {target_str} 之指紋、Bundle 與倒排索引快取。")
        return 0
    except SpaceNotFoundError as e:
        print(f"[knowledge-db] 空間不存在: {e}", file=sys.stderr)
        return 1
    except KnowledgeDBError as e:
        print(f"[knowledge-db] 操作失敗: {e}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"[knowledge-db] 執行異常: {e}", file=sys.stderr)
        return 1
