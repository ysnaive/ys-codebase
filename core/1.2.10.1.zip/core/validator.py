"""
Contributes Schema Validator and Lightweight DSL Engine.
100% Python Standard Library, Zero Third-Party Dependencies.
"""
from typing import Dict, Any, List, Optional, Tuple, NamedTuple, Mapping
import difflib
import copy
import re
import types
from core.context import get_runtime_context


class ValidationIssue(NamedTuple):
    path: str
    message: str
    severity: str = "ERROR"  # "ERROR" | "WARNING"
    suggestion: Optional[str] = None

    def __str__(self) -> str:
        s = f"[{self.severity}] {self.path}: {self.message}"
        if self.suggestion:
            s += f" ({self.suggestion})"
        return s


class ValidationResult:
    def __init__(self, is_valid: bool, issues: List[ValidationIssue], payload: Optional[Dict[str, Any]] = None):
        self.is_valid: bool = is_valid
        self.issues: List[ValidationIssue] = issues
        self.payload: Optional[Dict[str, Any]] = payload

    @property
    def errors(self) -> List[ValidationIssue]:
        return [i for i in self.issues if i.severity == "ERROR"]

    @property
    def warnings(self) -> List[ValidationIssue]:
        return [i for i in self.issues if i.severity == "WARNING"]

    def format_report(self, file_label: str = "") -> str:
        lines = []
        header = f"Contributes Validation Report: {file_label}" if file_label else "Contributes Validation Report"
        lines.append(f"=== {header} ===")
        if self.is_valid and not self.warnings:
            lines.append("[PASS] All definitions are valid.")
            return "\n".join(lines)
        for issue in self.issues:
            icon = "[FAIL]" if issue.severity == "ERROR" else "[WARN]"
            line = f"{icon} [{issue.path}] {issue.message}"
            if issue.suggestion:
                line += f"\n   [*] {issue.suggestion}"
            lines.append(line)
        if not self.is_valid:
            lines.append(
                "[Agent Directive] Please consult skill 'yscb-module-dev' "
                "(references/contributes_guide.md) to fix contributes schema violations."
            )
        return "\n".join(lines)


class _ContributesValidatorMeta(type):
    """Metaclass delegating `_SIGNATURE_PARSE_CACHE` to `RuntimeContext`."""

    @property
    def _SIGNATURE_PARSE_CACHE(cls) -> Dict[str, Dict[str, Any]]:
        return get_runtime_context().validator_signature_cache

    @_SIGNATURE_PARSE_CACHE.setter
    def _SIGNATURE_PARSE_CACHE(cls, value: Dict[str, Dict[str, Any]]) -> None:
        cache = get_runtime_context().validator_signature_cache
        cache.clear()
        if isinstance(value, dict):
            cache.update(value)


class ContributesValidator(metaclass=_ContributesValidatorMeta):
    """
    Lightweight Type Signature DSL Parser & Rigid Validator for YSCB Contributes.
    """
    MAX_RECURSION_DEPTH = 20

    # Type alias normalization map
    TYPE_ALIASES: Mapping[str, str] = types.MappingProxyType({
        "string": "str",
        "boolean": "bool",
        "integer": "int",
        "number": "float",
    })

    VALID_MERGE_STRATEGIES = ("merge", "extend", "replace", "unique")

    @staticmethod
    def _get_signature_cache() -> Dict[str, Dict[str, Any]]:
        return get_runtime_context().validator_signature_cache

    @staticmethod
    def _parse_default_literal(def_str: str) -> Any:
        """Parse literal default value from signature suffix."""
        if def_str.lower() in ("true", "false"):
            return def_str.lower() == "true"
        if re.match(r"^[+-]?\d+$", def_str):
            return int(def_str)
        if re.match(r"^[+-]?\d+\.\d+$", def_str):
            return float(def_str)
        if (def_str.startswith('"') and def_str.endswith('"')) or (def_str.startswith("'") and def_str.endswith("'")):
            return def_str[1:-1]
        if def_str == "[]":
            return []
        if def_str == "{}":
            return {}
        return def_str

    @staticmethod
    def _extract_attributes(raw_sig: str) -> Tuple[str, Dict[str, str]]:
        """
        Extract orthogonal `@<attr_name>(<attr_body>)` attributes from type signature string.
        Supports balanced nested parentheses inside `<attr_body>`.
        """
        attrs: Dict[str, str] = {}
        out_chars: List[str] = []
        i = 0
        n = len(raw_sig)
        while i < n:
            if raw_sig[i] == "@":
                m = re.match(r"^@([A-Za-z_][A-Za-z0-9_-]*)\(", raw_sig[i:])
                if m:
                    attr_name = m.group(1)
                    body_start = i + m.end()
                    depth = 1
                    j = body_start
                    while j < n and depth > 0:
                        if raw_sig[j] == "(":
                            depth += 1
                        elif raw_sig[j] == ")":
                            depth -= 1
                        j += 1
                    if depth == 0:
                        attrs[attr_name] = raw_sig[body_start : j - 1].strip()
                        i = j
                        continue
            out_chars.append(raw_sig[i])
            i += 1
        return "".join(out_chars).strip(), attrs

    @staticmethod
    def _split_top_level_delim(
        text: str,
        delim: str,
        from_right: bool = False,
    ) -> Optional[Tuple[str, str]]:
        """Splits `text` on `delim` only at top level (outside quotes and parentheses/brackets)."""
        depth = 0
        in_quote: Optional[str] = None
        match_idx: Optional[int] = None
        for idx, ch in enumerate(text):
            if in_quote:
                if ch == in_quote and (idx == 0 or text[idx - 1] != "\\"):
                    in_quote = None
                continue
            if ch in ("'", '"'):
                in_quote = ch
            elif ch in "([":
                depth += 1
            elif ch in ")]":
                depth = max(0, depth - 1)
            elif ch == delim and depth == 0:
                if not from_right:
                    return text[:idx].strip(), text[idx + 1 :].strip()
                match_idx = idx
        if match_idx is not None:
            return text[:match_idx].strip(), text[match_idx + 1 :].strip()
        return None

    @classmethod
    def parse_type_signature(cls, sig: str) -> Dict[str, Any]:
        """
        Parse type signature string:
        - "str!" -> type: "str", required: True
        - "str?" or "str" -> type: "str", required: False
        - "enum(a, b, c)!" -> type: "enum", enum_values: ["a", "b", "c"], required: True
        - "bool? = false" -> type: "bool", required: False, default: False
        - "$TypeName" -> type: "ref", ref_name: "TypeName", required: False
        - "$TypeName | merge" -> type: "ref", ref_name: "TypeName", merge_strategy: "merge"
        - "list[str]! | extend" -> type: "list", item_type: "str", required: True, merge_strategy: "extend"
        - "dict[str, str]" -> type: "dict", key_type: "str", value_type: "str"
        - "uri! @desc(欄位說明)" -> type: "uri", required: True, description: "欄位說明", attributes: {"desc": "欄位說明"}
        """
        cache = cls._get_signature_cache()
        cached_sig = cache.get(sig)
        if cached_sig is not None:
            return copy.deepcopy(cached_sig)

        raw, attributes = cls._extract_attributes(sig.strip())
        description = attributes.get("desc") or attributes.get("doc") or attributes.get("anno") or None
        merge_strategy: Optional[str] = None
        pipe_split = cls._split_top_level_delim(raw, "|", from_right=True)
        if pipe_split is not None:
            raw, strat_part = pipe_split
            merge_strategy = strat_part or None

        required = False
        default_val: Any = None
        has_default = False

        eq_split = cls._split_top_level_delim(raw, "=", from_right=False)
        if eq_split is not None:
            raw, def_part = eq_split
            default_val = cls._parse_default_literal(def_part)
            has_default = True

        if raw.endswith("!"):
            required = True
            raw = raw[:-1].strip()
        elif raw.endswith("?"):
            required = False
            raw = raw[:-1].strip()

        base_meta = {
            "required": required,
            "has_default": has_default,
            "default": default_val,
            "merge_strategy": merge_strategy,
            "description": description,
            "attributes": attributes,
            "raw": sig,
        }

        if raw.startswith("$"):
            res = {**base_meta, "type": "ref", "ref_name": raw[1:].strip()}
        elif raw.startswith("enum(") and raw.endswith(")"):
            enum_vals = [v.strip() for v in raw[5:-1].split(",") if v.strip()]
            res = {**base_meta, "type": "enum", "enum_values": enum_vals}
        elif (list_match := re.match(r"^list\[(.*)\]$", raw)):
            res = {
                **base_meta,
                "type": "list",
                "item_type": cls.parse_type_signature(list_match.group(1).strip()),
                "default": default_val if has_default else [],
            }
        elif raw.startswith("dict[") and raw.endswith("]") and (kv := cls._split_top_level_comma(raw[5:-1])) is not None:
            res = {
                **base_meta,
                "type": "dict",
                "key_type": cls.parse_type_signature(kv[0]),
                "value_type": cls.parse_type_signature(kv[1]),
                "default": default_val if has_default else {},
            }
        else:
            norm_type = cls.TYPE_ALIASES.get(raw.lower(), raw.lower())
            res = {**base_meta, "type": norm_type}
        cache[sig] = copy.deepcopy(res)
        return res

    @classmethod
    def _split_top_level_comma(cls, inner: str) -> Optional[Tuple[str, str]]:
        return cls._split_top_level_delim(inner, ",", from_right=False)

    @classmethod
    def _validate_primitive_or_container_rule(
        cls,
        data: Any,
        rule: Dict[str, Any],
        path: str,
        types_map: Dict[str, Any],
        depth: int,
    ) -> Tuple[Any, List[ValidationIssue]]:
        """Validate data against a parsed string type signature rule."""
        issues: List[ValidationIssue] = []
        expected_type = rule["type"]

        if expected_type == "ref":
            ref_name = rule["ref_name"]
            if ref_name not in types_map:
                issues.append(ValidationIssue(path=path, message=f"Undefined type reference '${ref_name}'.", severity="ERROR"))
                return data, issues
            return cls.validate_node(data, types_map[ref_name], path, types_map, depth + 1)

        if expected_type == "any":
            return data, issues

        primitive_checks = {
            "str": (lambda x: isinstance(x, str), "string"),
            "uri": (lambda x: isinstance(x, str) and len(x.strip()) > 0, "semantic URI or path string"),
            "path": (lambda x: isinstance(x, str) and len(x.strip()) > 0, "file/directory path string"),
            "int": (lambda x: isinstance(x, int) and not isinstance(x, bool), "integer"),
            "bool": (lambda x: isinstance(x, bool), "boolean"),
            "float": (lambda x: isinstance(x, (float, int)) and not isinstance(x, bool), "float"),
        }
        if expected_type in primitive_checks:
            pred, label = primitive_checks[expected_type]
            if not pred(data):
                issues.append(ValidationIssue(path=path, message=f"Expected {label}, got {type(data).__name__}.", severity="ERROR"))
            return data, issues

        if expected_type == "enum":
            allowed = rule["enum_values"]
            if not isinstance(data, str) or data not in allowed:
                matches = difflib.get_close_matches(str(data), allowed, n=1)
                hint = f"Did you mean '{matches[0]}'?" if matches else f"Expected one of {allowed}"
                issues.append(ValidationIssue(path=path, message=f"Invalid value '{data}'.", severity="ERROR", suggestion=hint))
            return data, issues

        if expected_type == "list":
            if not isinstance(data, list):
                issues.append(ValidationIssue(path=path, message=f"Expected list, got {type(data).__name__}.", severity="ERROR"))
                return data, issues
            out_list = []
            for idx, item in enumerate(data):
                out_item, sub_issues = cls.validate_node(item, rule["item_type"]["raw"], f"{path}[{idx}]", types_map, depth + 1)
                issues.extend(sub_issues)
                out_list.append(out_item)
            return out_list, issues

        if expected_type == "dict":
            if not isinstance(data, dict):
                issues.append(ValidationIssue(path=path, message=f"Expected dict, got {type(data).__name__}.", severity="ERROR"))
                return data, issues
            if "value_type" not in rule:
                return copy.copy(data), issues
            key_rule_raw = rule["key_type"]["raw"] if "key_type" in rule and isinstance(rule["key_type"], dict) else None
            val_rule_raw = rule["value_type"]["raw"]
            out_dict = {}
            for k, v in data.items():
                if isinstance(k, str) and k.startswith("__") and k.endswith("__"):
                    out_dict[k] = v
                    continue
                k_path = f"{path}.{k}" if path else str(k)
                if key_rule_raw is not None:
                    _, key_issues = cls.validate_node(k, key_rule_raw, k_path, types_map, depth + 1)
                    issues.extend(key_issues)
                out_v, sub_issues = cls.validate_node(v, val_rule_raw, k_path, types_map, depth + 1)
                issues.extend(sub_issues)
                out_dict[k] = out_v
            return out_dict, issues

        issues.append(ValidationIssue(path=path, message=f"Unknown primitive type '{expected_type}'.", severity="ERROR"))
        return data, issues

    @classmethod
    def _validate_dict_schema_node(
        cls,
        data: Any,
        schema: Dict[str, Any],
        path: str,
        types_map: Dict[str, Any],
        depth: int,
    ) -> Tuple[Any, List[ValidationIssue]]:
        """Validate data against an object/dict schema node."""
        issues: List[ValidationIssue] = []
        if not isinstance(data, dict):
            issues.append(ValidationIssue(path=path, message=f"Expected object/dict, got {type(data).__name__}.", severity="ERROR"))
            return data, issues

        if "$ref" in schema:
            ref_name = schema["$ref"].lstrip("$")
            if ref_name not in types_map:
                issues.append(ValidationIssue(path=path, message=f"Undefined type reference '${ref_name}'.", severity="ERROR"))
                return data, issues
            return cls.validate_node(data, types_map[ref_name], path, types_map, depth + 1)

        out_dict = copy.copy(data)
        has_wildcard = "*" in schema
        wildcard_schema = schema.get("*")
        defined_keys = {
            k for k in schema.keys()
            if k not in ("*", "_merge") and not (k == "required" and isinstance(schema.get(k), bool))
        }

        for k, v in data.items():
            if isinstance(k, str) and k.startswith("__") and k.endswith("__"):
                out_dict[k] = v
                continue
            k_path = f"{path}.{k}" if path else k
            if k in defined_keys:
                out_val, sub_issues = cls.validate_node(v, schema[k], k_path, types_map, depth + 1)
                issues.extend(sub_issues)
                out_dict[k] = out_val
            elif has_wildcard:
                out_val, sub_issues = cls.validate_node(v, wildcard_schema, k_path, types_map, depth + 1)
                issues.extend(sub_issues)
                out_dict[k] = out_val
            else:
                all_allowed = sorted(list(defined_keys))
                matches = difflib.get_close_matches(k, all_allowed, n=1)
                hint = f"Did you mean '{matches[0]}'?" if matches else f"Allowed fields: {all_allowed}"
                issues.append(ValidationIssue(path=k_path, message=f"Unknown field '{k}'.", severity="ERROR", suggestion=hint))

        for k in defined_keys:
            if k not in data:
                k_schema = schema[k]
                k_path = f"{path}.{k}" if path else k
                if isinstance(k_schema, str):
                    rule = cls.parse_type_signature(k_schema)
                    if rule["required"]:
                        issues.append(ValidationIssue(path=k_path, message=f"Missing required field '{k}'.", severity="ERROR"))
                    elif rule["has_default"]:
                        out_dict[k] = rule["default"]
                elif isinstance(k_schema, dict) and k_schema.get("required") is True:
                    issues.append(ValidationIssue(path=k_path, message=f"Missing required field '{k}'.", severity="ERROR"))

        return out_dict, issues

    @classmethod
    def validate_node(
        cls,
        data: Any,
        schema: Any,
        path: str,
        types_map: Dict[str, Any],
        depth: int = 0
    ) -> Tuple[Any, List[ValidationIssue]]:
        issues: List[ValidationIssue] = []

        if depth > cls.MAX_RECURSION_DEPTH:
            issues.append(ValidationIssue(
                path=path,
                message=f"Maximum recursion depth ({cls.MAX_RECURSION_DEPTH}) exceeded.",
                severity="ERROR"
            ))
            return data, issues

        if isinstance(schema, str):
            rule = cls.parse_type_signature(schema)
            return cls._validate_primitive_or_container_rule(data, rule, path, types_map, depth)

        if isinstance(schema, list):
            if not isinstance(data, list):
                issues.append(ValidationIssue(path=path, message=f"Expected list, got {type(data).__name__}.", severity="ERROR"))
                return data, issues
            if not schema:
                return data, issues
            item_schema = schema[0]
            out_list = []
            for idx, item in enumerate(data):
                out_item, sub_issues = cls.validate_node(item, item_schema, f"{path}[{idx}]", types_map, depth + 1)
                issues.extend(sub_issues)
                out_list.append(out_item)
            return out_list, issues

        if isinstance(schema, dict):
            return cls._validate_dict_schema_node(data, schema, path, types_map, depth)

        return data, issues

    @classmethod
    def validate(
        cls,
        target_mod: str,
        payload: Dict[str, Any],
        donor_mod: str = "",
        format_schema: Optional[Dict[str, Any]] = None,
        strict_points: bool = True
    ) -> ValidationResult:
        """
        Validate donor's contributes payload against target_mod's format_schema.
        """
        issues: List[ValidationIssue] = []

        if not isinstance(payload, dict):
            return ValidationResult(
                is_valid=False,
                issues=[ValidationIssue(path="", message=f"Payload must be a dictionary, got {type(payload).__name__}.", severity="ERROR")]
            )

        if format_schema is None:
            # Tolerant mode if no schema exists
            return ValidationResult(is_valid=True, issues=[], payload=payload)

        types_map = format_schema.get("_types", {})
        known_points = [k for k in format_schema.keys() if not k.startswith("_")]

        validated_payload = {}

        # 1. Strict boundary check on top-level keys
        for key, val in payload.items():
            if key.startswith("_"):
                continue  # Ignore internal metadata like __provider__

            if key not in known_points:
                if strict_points:
                    matches = difflib.get_close_matches(key, known_points, n=1)
                    hint = f"Did you mean '{matches[0]}'?" if matches else f"Target '{target_mod}' only accepts: {known_points}"
                    issues.append(ValidationIssue(
                        path=key,
                        message=f"Key '{key}' is not an accepted contribute point for module '{target_mod}'.",
                        severity="ERROR",
                        suggestion=hint
                    ))
                validated_payload[key] = val
                continue

            point_def = format_schema[key]
            point_format = point_def.get("format") if isinstance(point_def, dict) else point_def
            if point_format is None:
                validated_payload[key] = val
                continue

            node_out, node_issues = cls.validate_node(val, point_format, key, types_map, depth=0)
            issues.extend(node_issues)
            validated_payload[key] = node_out

        is_valid = len([i for i in issues if i.severity == "ERROR"]) == 0
        return ValidationResult(is_valid=is_valid, issues=issues, payload=validated_payload)

    @classmethod
    def _check_merge_strategy_value(
        cls,
        strat_val: Any,
        path: str,
        issues: List[ValidationIssue],
    ) -> None:
        if not isinstance(strat_val, str) or strat_val not in cls.VALID_MERGE_STRATEGIES:
            matches = difflib.get_close_matches(str(strat_val), cls.VALID_MERGE_STRATEGIES, n=1)
            hint = (
                f"Did you mean '{matches[0]}'?"
                if matches
                else f"Allowed merge strategies: {list(cls.VALID_MERGE_STRATEGIES)}"
            )
            issues.append(
                ValidationIssue(
                    path=path,
                    message=f"Invalid merge strategy '{strat_val}'.",
                    severity="ERROR",
                    suggestion=hint,
                )
            )

    @classmethod
    def _validate_schema_merge_strategies(
        cls,
        schema_node: Any,
        path: str,
        issues: List[ValidationIssue],
    ) -> None:
        """Recursively verify merge strategy modifiers in _format.json schema nodes."""
        if isinstance(schema_node, str):
            rule = cls.parse_type_signature(schema_node)
            strat = rule.get("merge_strategy")
            if strat is not None:
                cls._check_merge_strategy_value(strat, path, issues)
        elif isinstance(schema_node, dict):
            for k, v in schema_node.items():
                k_path = f"{path}.{k}" if path else k
                if k == "_merge":
                    cls._check_merge_strategy_value(v, k_path, issues)
                else:
                    cls._validate_schema_merge_strategies(v, k_path, issues)
        elif isinstance(schema_node, list):
            for idx, item in enumerate(schema_node):
                cls._validate_schema_merge_strategies(item, f"{path}[{idx}]", issues)

    @classmethod
    def validate_format_schema(cls, format_schema: Dict[str, Any]) -> ValidationResult:
        """
        Meta-Check: Validate _format.json structure itself.
        """
        issues: List[ValidationIssue] = []
        if not isinstance(format_schema, dict):
            return ValidationResult(
                is_valid=False,
                issues=[ValidationIssue(path="", message="Format schema must be a dictionary.", severity="ERROR")]
            )

        types_map = format_schema.get("_types", {})
        if not isinstance(types_map, dict):
            issues.append(ValidationIssue(path="_types", message="_types must be a dictionary.", severity="ERROR"))
        else:
            cls._validate_schema_merge_strategies(types_map, "_types", issues)

        points = [k for k in format_schema.keys() if not k.startswith("_")]
        if not points:
            issues.append(ValidationIssue(path="", message="No contribution points defined in format schema.", severity="WARNING"))

        for pt in points:
            p_def = format_schema[pt]
            if not isinstance(p_def, dict):
                issues.append(ValidationIssue(path=pt, message=f"Contribute point definition must be an object with 'description' and 'format'.", severity="ERROR"))
                continue
            if "description" not in p_def or not isinstance(p_def["description"], str):
                issues.append(ValidationIssue(path=f"{pt}.description", message="Missing or non-string 'description'.", severity="ERROR"))
            if "merge" in p_def:
                cls._check_merge_strategy_value(p_def["merge"], f"{pt}.merge", issues)
            if "format" not in p_def:
                issues.append(ValidationIssue(path=f"{pt}.format", message="Missing 'format' specification.", severity="ERROR"))
            else:
                cls._validate_schema_merge_strategies(p_def["format"], f"{pt}.format", issues)

        is_valid = len([i for i in issues if i.severity == "ERROR"]) == 0
        return ValidationResult(is_valid=is_valid, issues=issues)


def __getattr__(name: str) -> Any:
    """PEP 562 backward-compatible attribute delegation to active `RuntimeContext`."""
    if name == "_SIGNATURE_PARSE_CACHE":
        return get_runtime_context().validator_signature_cache
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
