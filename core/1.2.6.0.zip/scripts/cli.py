"""
Core Module CLI Entrypoint - Precise Command Handlers Contract.
No legacy process(args) fallback.
"""
import builtins
import json
import os
import sys
from typing import Any, List

from core.commands.bags import CmdBags, CmdOption
from core.guard import guard_dispatch
from core.installer import Installer
from core import config as core_config
from core import uri as core_uri


def _render_subcommand_group_help(cmd_name: str) -> int:
    """Render help message for a core subcommand group (config, uri, event, contributes)."""
    from core.commands.help import HelpRenderer
    from core.commands.dispatcher import _load_registry, _get_yscb_root
    _, yscb_abs = _get_yscb_root()
    reg = _load_registry(yscb_abs)
    spec = reg.get_command("core", cmd_name)
    print(HelpRenderer.render_cmd_help("core", cmd_name, spec))
    return 0


def _parse_cli_scalar_or_json(raw_val: str) -> Any:
    """Parse CLI raw string value into boolean, null, integer, JSON container, or plain string."""
    low = raw_val.lower()
    if low == "true":
        return True
    if low == "false":
        return False
    if low in ("none", "null"):
        return None
    if raw_val.isdigit():
        return int(raw_val)
    if raw_val.startswith(("[", "{")) and raw_val.endswith(("]", "}")):
        import json
        try:
            return json.loads(raw_val)
        except Exception:
            return raw_val
    return raw_val


def _normalize_bags(cmd_bags: Any, default_cmd: str = "") -> CmdBags:
    """Normalize input into CmdBags for compatibility with direct list invocations."""
    if isinstance(cmd_bags, CmdBags):
        return cmd_bags
    if isinstance(cmd_bags, (builtins.list, tuple)):
        args = []
        options = {}
        for a in cmd_bags:
            if a.startswith("--"):
                if "=" in a:
                    k, v = a[2:].split("=", 1)
                    options[k] = CmdOption(name=k, params=v)
                else:
                    k = a[2:]
                    options[k] = CmdOption(name=k, params=True)
            elif a.startswith("-") and len(a) > 1:
                k = a[1:]
                options[k] = CmdOption(name=k, params=True)
            else:
                args.append(a)
        raw_cmd_str = " ".join([str(x) for x in cmd_bags])
        return CmdBags(raw_cmd=raw_cmd_str, command=default_cmd, args=args, options=options)
    return CmdBags(raw_cmd="", command=default_cmd)


def config_list(cmd_bags: CmdBags) -> int:
    """List module configurations."""
    guard_dispatch("core")
    cmd_bags = _normalize_bags(cmd_bags)
    json_output = cmd_bags.has_option("json")
    local_only = cmd_bags.has_option("local")
    mod_filter = cmd_bags.get_option_value("mod")

    mods = [mod_filter] if mod_filter else core_config.list_modules()
    if not mods:
        print("[core:config] No configuration found for any module.")
        return 0

    summary = {}
    for m in mods:
        has_local = os.path.isfile(core_config.get_config_path(m, local=True))
        if local_only and not has_local:
            continue
        cfg_data = core_config.get_raw(m, local=True) if local_only else core_config.get_all(m)
        summary[m] = {
            "config": cfg_data,
            "has_project_config": os.path.isfile(core_config.get_config_path(m, local=False)),
            "has_local_config": has_local,
        }

    if json_output:
        import json
        print(json.dumps(summary, indent=2, ensure_ascii=False))
        return 0

    print("\nYS-Codebase Module Configurations:")
    print("=" * 80)
    for m, info in summary.items():
        local_flag_txt = "[LOCAL OVERLAY]" if info["has_local_config"] else "[PROJECT]"
        print(f"[*] Module: {m} {local_flag_txt}")
        print(f"    |-- Project: {core_config.get_config_path(m, local=False)}")
        if info["has_local_config"]:
            print(f"    |-- Local  : {core_config.get_config_path(m, local=True)}")
        cfg_items = info["config"]
        if isinstance(cfg_items, dict) and cfg_items:
            for k, v in cfg_items.items():
                print(f"    • {k}: {v}")
        else:
            print("    • (empty)")
    print("=" * 80)
    return 0


def config_inspect(cmd_bags: CmdBags) -> int:
    """Inspect effective value, source hierarchy and override status of a key."""
    guard_dispatch("core")
    cmd_bags = _normalize_bags(cmd_bags)
    if len(cmd_bags.args) < 2:
        print("[core:config] Error: Module name and key required. (e.g. 'config inspect core project_root [--json]')")
        return 1

    mod_name, key = cmd_bags.args[0], cmd_bags.args[1]
    json_output = cmd_bags.has_option("json")

    res = core_config.inspect(mod_name, key)
    if json_output:
        import json
        print(json.dumps(res, indent=2, ensure_ascii=False))
        return 0

    print(f"\nConfiguration Inspection: '{mod_name}' -> '{key}'")
    print("-" * 60)
    print(f"  Effective Value : {res.get('effective')}")
    print(f"  Source Hierarchy: {res.get('source')}")
    print(f"  Project Value   : {res.get('project_value')}")
    print(f"  Local Value     : {res.get('local_value')}")
    print(f"  Is Overridden   : {res.get('is_overridden')}")
    print("-" * 60)
    return 0


def config_unset(cmd_bags: CmdBags) -> int:
    """Delete a configuration key from project or local overlay."""
    guard_dispatch("core")
    cmd_bags = _normalize_bags(cmd_bags)
    if len(cmd_bags.args) < 2:
        print("[core:config] Error: Module name and key required. (e.g. 'config unset core project_root [--local]')")
        return 1

    mod_name, key = cmd_bags.args[0], cmd_bags.args[1]
    local_flag = cmd_bags.has_option("local")

    try:
        deleted = core_config.delete(mod_name, key, local=local_flag)
        tier_name = "config.local.json" if local_flag else "config.project.json"
        if deleted:
            print(f"[core:config] Successfully unset '{key}' from '{tier_name}' for module '{mod_name}'.")
            return 0
        else:
            print(f"[core:config] Key '{key}' not found in '{tier_name}' for module '{mod_name}'.")
            return 1
    except Exception as e:
        print(f"[core:config] Error unsetting config: {e}")
        return 1



def config_get(cmd_bags: CmdBags) -> int:
    """Get effective configuration value."""
    guard_dispatch("core")
    cmd_bags = _normalize_bags(cmd_bags)
    if not cmd_bags.args:
        print("[core:config] Error: Module name required. (e.g. 'config get agents-workflow paths.plans')")
        return 1
    mod_name = cmd_bags.args[0]
    key = cmd_bags.args[1] if len(cmd_bags.args) > 1 else None
    json_output = cmd_bags.has_option("json")

    val = core_config.get(mod_name, key)
    if json_output or isinstance(val, (dict, builtins.list)):
        import json
        print(json.dumps(val, indent=2, ensure_ascii=False))
    else:
        print(val)
    return 0


def config_set(cmd_bags: CmdBags) -> int:
    """Set configuration value."""
    guard_dispatch("core")
    cmd_bags = _normalize_bags(cmd_bags)
    if len(cmd_bags.args) < 3:
        print("[core:config] Error: Module name, key, and value required. (e.g. 'config set core project_root ./ [--local]')")
        return 1

    mod_name, key, raw_val = cmd_bags.args[0], cmd_bags.args[1], cmd_bags.args[2]
    local_flag = cmd_bags.has_option("local")
    val = _parse_cli_scalar_or_json(raw_val)

    try:
        core_config.set(mod_name, key, val, local=local_flag)
        tier_name = "config.local.json" if local_flag else "config.project.json"
        print(f"[core:config] Successfully set '{key}' = {val} in '{tier_name}' for module '{mod_name}'.")
        return 0
    except Exception as e:
        print(f"[core:config] Error setting config: {e}")
        return 1


def config_reload(cmd_bags: CmdBags) -> int:
    """Reload cached configuration."""
    guard_dispatch("core")
    cmd_bags = _normalize_bags(cmd_bags)
    mod_name = cmd_bags.args[0] if cmd_bags.args else None
    core_config.reload(mod_name)
    print(f"[core:config] Reloaded configuration cache for {'all modules' if not mod_name else mod_name}.")
    return 0


def config(cmd_bags: CmdBags) -> int:
    """YS-Codebase Module Configuration Manager (Group Dispatcher)."""
    cmd_bags = _normalize_bags(cmd_bags)
    args = cmd_bags.args

    if not args:
        return _render_subcommand_group_help("config")

    sub_cmd = args[0]
    sub_bags = CmdBags(raw_cmd=cmd_bags.raw_cmd, command=sub_cmd, args=args[1:], options=cmd_bags.options)
    if sub_cmd == "list":
        return config_list(sub_bags)
    elif sub_cmd == "get":
        return config_get(sub_bags)
    elif sub_cmd == "set":
        return config_set(sub_bags)
    elif sub_cmd == "inspect":
        return config_inspect(sub_bags)
    elif sub_cmd == "unset":
        return config_unset(sub_bags)
    elif sub_cmd == "reload":
        return config_reload(sub_bags)
    else:
        print(f"[core:config] Unknown sub-command '{sub_cmd}'. Run 'python yscb.py config --help' for help.")
        return 1


def uri_list(cmd_bags: CmdBags) -> int:
    """List all registered semantic URI schemes."""
    guard_dispatch("core")
    schemes = core_uri.list_registered_schemes_summary()
    print("\nYS-Codebase Registered URI Schemes Catalog:")
    print("=" * 110)
    print(f"{'SCHEME':<23} {'TYPE':<8} {'PROVIDER':<12} {'RAW TARGET / VALUE':<28} {'RESOLVED PATH'}")
    print("-" * 110)
    for s in schemes:
        token_str = f"{s['token']}://"
        stype = s.get("type", "const")
        provider = s.get("provider", "core")
        raw_val = s.get("value", "")
        res_path = s.get("resolved_path", "")
        print(f"{token_str:<23} {stype:<8} {provider:<12} {raw_val:<28} {res_path}")
    print("=" * 110)
    return 0


def uri_resolve(cmd_bags: CmdBags) -> int:
    """Resolve semantic URI to absolute physical path."""
    guard_dispatch("core")
    cmd_bags = _normalize_bags(cmd_bags)
    if not cmd_bags.args:
        print("[core:uri] Error: URI string required.")
        return 1
    try:
        res = core_uri.resolve(cmd_bags.args[0], interactive=True)
        print(res)
        return 0
    except Exception as e:
        print(f"[core:uri] Error: {e}")
        return 1


def uri_to_uri(cmd_bags: CmdBags) -> int:
    """Convert absolute path to semantic URI."""
    guard_dispatch("core")
    cmd_bags = _normalize_bags(cmd_bags)
    if not cmd_bags.args:
        print("[core:uri] Error: Absolute path required.")
        return 1
    try:
        res = core_uri.to_uri(cmd_bags.args[0])
        print(res)
        return 0
    except Exception as e:
        print(f"[core:uri] Error: {e}")
        return 1


def uri_check(cmd_bags: CmdBags) -> int:
    """Health check all registered URI schemes."""
    guard_dispatch("core")
    schemes = core_uri.list_registered_schemes_summary()
    print("\nYS-Codebase URI Health Check:")
    print("-" * 80)
    healthy = True
    quick_fixes: List[str] = []
    for s in schemes:
        status = "OK" if not s["resolved_path"].startswith("!undefined") else "UNDEFINED"
        if status == "UNDEFINED":
            healthy = False
            hint_fn = getattr(core_uri, "format_undefined_uri_hint", None)
            if callable(hint_fn):
                hint_cmd = hint_fn(
                    s.get("token", ""),
                    s.get("provider", "core"),
                    s.get("value", "unknown"),
                )
                if hint_cmd not in quick_fixes:
                    quick_fixes.append(hint_cmd)
        print(f"[*] {s['token'] + '://':<18} -> {s['resolved_path']} [{status}]")
    print("-" * 80)
    print(f"Overall URI Status: {'HEALTHY' if healthy else 'WARNING (!undefined schemes present)'}")
    if quick_fixes:
        print("\n[Quick Fix] Run the following command(s) to initialize undefined schemes:")
        for qf in quick_fixes:
            print(f"  + {qf}")
    return 0


def uri(cmd_bags: CmdBags) -> int:
    """YS-Codebase Semantic URI VFS CLI (Group Dispatcher)."""
    cmd_bags = _normalize_bags(cmd_bags)
    args = cmd_bags.args

    if not args:
        return _render_subcommand_group_help("uri")

    sub_cmd = args[0]
    sub_bags = CmdBags(raw_cmd=cmd_bags.raw_cmd, command=sub_cmd, args=args[1:], options=cmd_bags.options)
    if sub_cmd in ("list", "--list", "-l"):
        return uri_list(sub_bags)
    elif sub_cmd == "resolve":
        return uri_resolve(sub_bags)
    elif sub_cmd == "to-uri":
        return uri_to_uri(sub_bags)
    elif sub_cmd == "check":
        return uri_check(sub_bags)
    else:
        print(f"[core:uri] Unknown sub-command '{sub_cmd}'. Run 'python yscb.py uri --help' for help.")
        return 1



def install(cmd_bags: CmdBags) -> int:
    """Install one or more modules from provider or local build package (@build)."""
    guard_dispatch("core")
    if not cmd_bags.args:
        print("[core:install] Error: Module name is required.")
        return 1

    version = cmd_bags.get_option_value("version")
    provider = cmd_bags.get_option_value("provider")
    force_flag = cmd_bags.has_option("force")
    ignore_sha256 = cmd_bags.has_option("ignore-sha256")

    specs = cmd_bags.args
    if len(specs) == 1:
        module_spec = specs[0]
        if "@" in module_spec:
            module_target, version = module_spec.split("@", 1)
        else:
            module_target = module_spec
    else:
        module_target = [s for s in specs]

    installer = Installer()
    return installer.cmd_install(
        module_target,
        version=version,
        provider=provider,
        force=force_flag,
        ignore_sha256=ignore_sha256,
    )


def update(cmd_bags: CmdBags) -> int:
    """Update installed module(s) to latest version."""
    guard_dispatch("core")
    if not cmd_bags.args:
        mod_target = None
    elif len(cmd_bags.args) == 1:
        mod_target = cmd_bags.args[0]
    else:
        mod_target = [s for s in cmd_bags.args]
    provider = cmd_bags.get_option_value("provider")
    ignore_sha256 = cmd_bags.has_option("ignore-sha256")
    installer = Installer()
    return installer.cmd_update(mod_target, provider=provider, ignore_sha256=ignore_sha256)


def remove(cmd_bags: CmdBags) -> int:
    """Remove one or more installed modules from environment."""
    guard_dispatch("core")
    if not cmd_bags.args:
        mod_target = ""
    elif len(cmd_bags.args) == 1:
        mod_target = cmd_bags.args[0]
    else:
        mod_target = [s for s in cmd_bags.args]
    clean = cmd_bags.has_option("clean")
    purge = cmd_bags.has_option("purge")
    force_flag = cmd_bags.has_option("force")
    installer = Installer()
    return installer.cmd_remove(mod_target, clean=clean, purge=purge, force=force_flag)


def list(cmd_bags: CmdBags) -> int:
    """List all installed modules, versions and providers."""
    guard_dispatch("core")
    remote = cmd_bags.has_option("remote")
    provider = cmd_bags.get_option_value("provider")
    installer = Installer()
    return installer.cmd_list(remote=remote, provider=provider)


def status(cmd_bags: CmdBags) -> int:
    """Health check and runtime diagnostic report."""
    guard_dispatch("core")
    installer = Installer()
    return installer.cmd_status()


def reload(cmd_bags: CmdBags) -> int:
    """Reconcile and refresh runtime environment."""
    guard_dispatch("core")
    installer = Installer()
    return installer.cmd_reload()


def rollback(cmd_bags: CmdBags) -> int:
    """Revert environment to the previous snapshot state."""
    guard_dispatch("core")
    target = cmd_bags.args[0] if cmd_bags.args else None
    installer = Installer()
    return installer.cmd_rollback(target)


def restore(cmd_bags: CmdBags) -> int:
    """Restore missing installed modules from mirror or provider."""
    guard_dispatch("core")
    force_flag = cmd_bags.has_option("force")
    provider = cmd_bags.get_option_value("provider")
    ignore_sha256 = cmd_bags.has_option("ignore-sha256")
    installer = Installer()
    return installer.cmd_restore(force=force_flag, provider=provider, ignore_sha256=ignore_sha256)


def event_list(cmd_bags: CmdBags) -> int:
    """List all registered ecosystem events."""
    guard_dispatch("core")
    from core import events
    contributed = events.get_contributed_events()
    print("=" * 70)
    print("  YS-Codebase - Ecosystem Event Registry")
    print("=" * 70)
    if not contributed:
        print("  (No contributed events found)")
    else:
        for mod_name, ev_list in sorted(contributed.items()):
            print(f"\n[{mod_name}]")
            for ev in ev_list:
                ename = ev.get("name", "")
                edesc = ev.get("description", "")
                print(f"  {ename:<25} {edesc}")
    print("\n" + "=" * 70)
    return 0


def event(cmd_bags: CmdBags) -> int:
    """Ecosystem Event Registry and Inspector (Group Dispatcher)."""
    guard_dispatch("core")
    cmd_bags = _normalize_bags(cmd_bags)
    if not cmd_bags.args:
        return _render_subcommand_group_help("event")
    sub_cmd = cmd_bags.args[0]
    if sub_cmd == "list":
        return event_list(cmd_bags)
    else:
        print(f"[core:event] Unknown subcommand '{sub_cmd}'. Available: list")
        return 1


def contributes_list(cmd_bags: CmdBags) -> int:
    """List registered contribute points."""
    guard_dispatch("core")
    cmd_bags = _normalize_bags(cmd_bags)
    from core.commands import contributes_cmd
    mod_filter = cmd_bags.get_option_value("module") or cmd_bags.get_option_value("m")
    if not mod_filter and cmd_bags.args:
        mod_filter = cmd_bags.args[0]
    return contributes_cmd.list_contributes(mod_filter)


def contributes_check(cmd_bags: CmdBags) -> int:
    """Check contributes against schema."""
    guard_dispatch("core")
    cmd_bags = _normalize_bags(cmd_bags)
    from core.commands import contributes_cmd
    target = cmd_bags.args[0] if cmd_bags.args else None
    is_format = cmd_bags.has_option("format")
    return contributes_cmd.check_contributes(target, is_format_check=is_format)


def contributes(cmd_bags: CmdBags) -> int:
    """Contributes Schema Validation and Inspection Manager (Group Dispatcher)."""
    guard_dispatch("core")
    cmd_bags = _normalize_bags(cmd_bags)
    args = cmd_bags.args
    if not args:
        return _render_subcommand_group_help("contributes")
    sub_cmd = args[0]
    sub_args = args[1:]
    sub_bags = CmdBags(
        raw_cmd=cmd_bags.raw_cmd,
        command=sub_cmd,
        args=sub_args,
        options=cmd_bags.options,
    )
    if sub_cmd == "list":
        return contributes_list(sub_bags)
    elif sub_cmd == "check":
        return contributes_check(sub_bags)
    else:
        print(f"[core:contributes] Unknown subcommand '{sub_cmd}'. Available: list, check", file=sys.stderr)
        return 1


def gitignore_status(cmd_bags: CmdBags) -> int:
    """Inspect project://.gitignore managed block status and grouped module rules."""
    guard_dispatch("core")
    cmd_bags = _normalize_bags(cmd_bags)
    from core import gitignore as gi_mod
    info = gi_mod.status()
    if cmd_bags.has_option("json"):
        print(json.dumps(info, indent=2, ensure_ascii=False))
        return 0
    print("=" * 70)
    print("  YS-Codebase - Unified Gitignore Status")
    print("=" * 70)
    print(f"  Target File    : {info.get('target_path')}")
    print(f"  Exists         : {info.get('exists')}")
    print(f"  Managed Block  : {info.get('has_managed_block')}")
    print(f"  In Sync        : {info.get('in_sync')}")
    print(f"  Total Rules    : {info.get('total_patterns')}")
    groups = info.get("groups", {})
    if groups:
        print("\n  Module Groups:")
        for mod, pats in groups.items():
            print(f"    # [{mod}] ({len(pats)} rule(s))")
    print("=" * 70)
    return 0


def gitignore_sync(cmd_bags: CmdBags) -> int:
    """Synthesize and synchronize all module ignore rules into project://.gitignore."""
    guard_dispatch("core")
    cmd_bags = _normalize_bags(cmd_bags)
    from core import gitignore as gi_mod
    res = gi_mod.sync()
    if cmd_bags.has_option("json"):
        print(json.dumps(res, indent=2, ensure_ascii=False))
        return 0 if not res.get("error") else 1
    if res.get("error"):
        print(f"[core:gitignore] Error: {res['error']}", file=sys.stderr)
        return 1
    state_label = "created" if res.get("created") else ("updated" if res.get("updated") else "already up-to-date")
    print(
        f"[core:gitignore] '{res.get('target_path')}' is {state_label} "
        f"({len(res.get('patterns', []))} rule(s) across {len(res.get('groups', {}))} module group(s))."
    )
    return 0


def gitignore(cmd_bags: CmdBags) -> int:
    """Unified project://.gitignore managed block inspector and synchronizer (Group Dispatcher)."""
    guard_dispatch("core")
    cmd_bags = _normalize_bags(cmd_bags)
    args = cmd_bags.args
    if not args:
        return _render_subcommand_group_help("gitignore")
    sub_cmd = args[0]
    sub_args = args[1:]
    sub_bags = CmdBags(
        raw_cmd=cmd_bags.raw_cmd,
        command=sub_cmd,
        args=sub_args,
        options=cmd_bags.options,
    )
    if sub_cmd == "status":
        return gitignore_status(sub_bags)
    elif sub_cmd == "sync":
        return gitignore_sync(sub_bags)
    else:
        print(f"[core:gitignore] Unknown subcommand '{sub_cmd}'. Available: status, sync", file=sys.stderr)
        return 1
