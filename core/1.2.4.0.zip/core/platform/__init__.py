"""
Core Platform - Cross-Platform OS & Process Abstraction SDK.
"""

from core.platform import daemon_probe
from core.platform.lock import InterProcessLock, LockAcquisitionError
from core.platform.process import (
    can_spawn_background_daemon,
    is_process_alive,
    kill_process_tree,
    set_process_title,
    spawn_detached,
    terminate_popen_tree,
)
from core.platform.venv import ensure_private_venv, get_venv_site_packages

__all__ = [
    "daemon_probe",
    "can_spawn_background_daemon",
    "spawn_detached",
    "is_process_alive",
    "kill_process_tree",
    "terminate_popen_tree",
    "set_process_title",
    "InterProcessLock",
    "LockAcquisitionError",
    "ensure_private_venv",
    "get_venv_site_packages",
]
