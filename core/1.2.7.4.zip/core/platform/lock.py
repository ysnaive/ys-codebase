"""
Core Platform - Cross-Platform Inter-Process Lock.

Provides a robust, reentrant-safe, non-blocking file-based mutex across
Linux/POSIX (fcntl.flock) and Windows (msvcrt.locking).
"""

import errno
import os
import sys
import time
from typing import Optional

_EEXIST_RETRIES: int = 3


class LockAcquisitionError(Exception):
    """Raised when an inter-process lock cannot be acquired."""
    pass


class InterProcessLock:
    """
    Cross-platform inter-process file lock.

    Guarantees mutual exclusion between separate processes on both POSIX
    (via fcntl.flock) and Windows (via msvcrt.locking).
    """

    def __init__(self, lock_file: str, timeout: float = 0.0) -> None:
        self.lock_file = os.path.abspath(lock_file)
        self.timeout = float(timeout)
        self._fd: Optional[int] = None
        self._is_locked: bool = False

    @property
    def is_locked(self) -> bool:
        return self._is_locked

    def acquire(self, blocking: bool = False, timeout_sec: float = 0.0) -> bool:
        """
        Attempts to acquire the lock.

        Args:
            blocking: If True, waits until the lock is acquired or timeout expires.
            timeout_sec: Maximum seconds to wait when blocking is True (0 = wait indefinitely).

        Returns:
            bool: True if lock was acquired, False otherwise.
        """
        if self._is_locked:
            return True

        parent_dir = os.path.dirname(self.lock_file)
        if parent_dir and not os.path.exists(parent_dir):
            os.makedirs(parent_dir, exist_ok=True)

        fd = self._open_lock_fd()
        try:
            start_time = time.time()
            while True:
                if self._try_lock_fd(fd):
                    if sys.platform != "win32":
                        try:
                            st_fd = os.fstat(fd)
                            st_path = os.stat(self.lock_file)
                            if (st_fd.st_dev, st_fd.st_ino) != (st_path.st_dev, st_path.st_ino):
                                self._unlock_fd(fd)
                                os.close(fd)
                                fd = self._open_lock_fd()
                                continue
                        except FileNotFoundError:
                            self._unlock_fd(fd)
                            os.close(fd)
                            fd = self._open_lock_fd()
                            continue
                    self._fd = fd
                    self._is_locked = True
                    return True

                if not blocking:
                    os.close(fd)
                    return False

                if timeout_sec > 0 and (time.time() - start_time) >= timeout_sec:
                    os.close(fd)
                    return False

                time.sleep(0.05)
        except BaseException:
            try:
                os.close(fd)
            except OSError:
                pass
            raise

    def _open_lock_fd(self) -> int:
        """
        Opens (creating if needed) the lock file descriptor.

        Some filesystems (e.g. shared/9p mounts) transiently raise ``FileExistsError``
        for ``O_CREAT`` when another process races on creating the same file. Retries
        up to ``_EEXIST_RETRIES`` times (50ms apart) re-opening without ``O_CREAT``;
        re-raises the original ``FileExistsError`` if all retries fail. Other errors propagate.
        """
        try:
            fd = os.open(self.lock_file, os.O_CREAT | os.O_RDWR)
            os.set_inheritable(fd, False)
            return fd
        except FileExistsError as first_err:
            original = first_err
        for _ in range(_EEXIST_RETRIES):
            time.sleep(0.05)
            try:
                fd = os.open(self.lock_file, os.O_RDWR)
                os.set_inheritable(fd, False)
                return fd
            except FileExistsError:
                continue
        raise original

    def release(self) -> None:
        """Releases the lock and closes the underlying file descriptor."""
        if not self._is_locked or self._fd is None:
            return

        try:
            self._unlock_fd(self._fd)
        finally:
            try:
                os.close(self._fd)
            except OSError:
                pass
            self._fd = None
            self._is_locked = False

    def _try_lock_fd(self, fd: int) -> bool:
        fatal_errnos = (
            getattr(errno, "ENOTSUP", -1),
            getattr(errno, "EOPNOTSUPP", -1),
            getattr(errno, "ENOSYS", -1),
            errno.EBADF,
            errno.EINVAL,
        )
        if sys.platform == "win32":
            try:
                import msvcrt
                os.lseek(fd, 0, os.SEEK_SET)
                msvcrt.locking(fd, msvcrt.LK_NBLCK, 1)
                return True
            except (IOError, OSError) as e:
                if e.errno in fatal_errnos:
                    raise
                win_err = getattr(e, "winerror", None)
                if e.errno in (errno.EACCES, errno.EAGAIN, getattr(errno, "EDEADLK", 36)) or win_err == 33:
                    return False
                if e.errno is not None:
                    raise
                return False
        else:
            posix_contention = {
                errno.EACCES,
                errno.EAGAIN,
                getattr(errno, "EWOULDBLOCK", errno.EAGAIN),
            }
            try:
                import fcntl
                fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                return True
            except (IOError, OSError) as e:
                if e.errno in fatal_errnos:
                    raise
                if e.errno in posix_contention:
                    return False
                raise

    def _unlock_fd(self, fd: int) -> None:
        if sys.platform == "win32":
            try:
                import msvcrt
                os.lseek(fd, 0, os.SEEK_SET)
                msvcrt.locking(fd, msvcrt.LK_UNLCK, 1)
            except (IOError, OSError):
                pass
        else:
            try:
                import fcntl
                fcntl.flock(fd, fcntl.LOCK_UN)
            except (IOError, OSError):
                pass

    def __enter__(self) -> "InterProcessLock":
        if not self.acquire(blocking=True, timeout_sec=self.timeout):
            raise LockAcquisitionError(f"Could not acquire inter-process lock on {self.lock_file}")
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.release()

    def __del__(self) -> None:
        try:
            self.release()
        except Exception:
            pass
